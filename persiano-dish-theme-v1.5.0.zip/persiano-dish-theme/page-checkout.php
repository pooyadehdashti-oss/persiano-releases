<?php
/**
 * Checkout page.
 *
 * @package Persiano_Dish
 */
get_header();

$is_received = function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' );
?>
<section class="pd-commerce-hero<?php echo $is_received ? ' pd-commerce-hero--success' : ''; ?>">
    <div class="pd-shell pd-commerce-hero-grid">
        <div>
            <div class="pd-kicker"><?php echo $is_received ? esc_html__( 'Order received', 'persiano-dish' ) : esc_html__( 'Checkout', 'persiano-dish' ); ?></div>
            <h1><?php echo $is_received ? esc_html__( 'Thank you for your order.', 'persiano-dish' ) : esc_html__( 'Almost at the table.', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-commerce-hero-copy">
            <?php if ( $is_received ) : ?>
                <p><?php esc_html_e( 'Your order details and payment confirmation are below. Keep your confirmation email for reference.', 'persiano-dish' ); ?></p>
            <?php else : ?>
                <p><?php esc_html_e( 'Enter your details, choose the available fulfilment option and complete payment. Your final order summary will appear before you place the order.', 'persiano-dish' ); ?></p>
                <div class="pd-inline-notes"><span><?php esc_html_e( 'Secure payment', 'persiano-dish' ); ?></span><span><?php esc_html_e( 'Pickup & delivery options', 'persiano-dish' ); ?></span><span><?php esc_html_e( 'Email confirmation', 'persiano-dish' ); ?></span></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="pd-commerce-section pd-checkout-section">
    <div class="pd-shell pd-commerce-shell">
        <?php while ( have_posts() ) : the_post(); ?>
            <div class="pd-commerce-content pd-checkout-content">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</section>
<?php get_footer(); ?>
