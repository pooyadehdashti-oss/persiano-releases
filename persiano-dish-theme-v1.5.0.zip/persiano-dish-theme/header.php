<?php
/**
 * Site header.
 *
 * @package Persiano_Dish
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="pd-site-header">
    <div class="pd-shell pd-header-inner">
        <a class="pd-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
            <?php persiano_dish_render_logo( 'header' ); ?>
        </a>

        <nav class="pd-primary-nav" id="site-navigation" aria-label="<?php esc_attr_e( 'Primary Navigation', 'persiano-dish' ); ?>">
            <?php
            wp_nav_menu(
                array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => 'persiano_dish_fallback_menu',
                    'depth'          => 1,
                )
            );
            ?>
        </nav>

        <div class="pd-header-actions">
            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                <a class="pd-cart-link" href="<?php echo esc_url( persiano_dish_get_cart_url() ); ?>" aria-label="<?php esc_attr_e( 'View cart', 'persiano-dish' ); ?>">
                    <svg class="pd-cart-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M7 7.75h10.3l-.68 10H7.68L7 7.75Zm1.6 0a3.4 3.4 0 0 1 6.8 0" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span class="pd-cart-count"><?php echo esc_html( persiano_dish_cart_count() ); ?></span>
                </a>
            <?php endif; ?>
            <a class="pd-btn pd-order-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week', '/shop/' ) ); ?>"><?php esc_html_e( 'Order Online', 'persiano-dish' ); ?></a>
            <button class="pd-menu-toggle" type="button" aria-controls="site-navigation" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open menu', 'persiano-dish' ); ?>">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</header>
<?php persiano_dish_render_global_search(); ?>
<main id="primary" class="pd-site-main">
