<?php
/**
 * Persiano Dish theme functions.
 *
 * @package Persiano_Dish
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PERSIANO_DISH_VERSION', '1.5.0' );

function persiano_dish_setup() {
    load_theme_textdomain( 'persiano-dish', get_template_directory() . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'style.css' );

    add_theme_support(
        'custom-logo',
        array(
            'height'      => 120,
            'width'       => 360,
            'flex-height' => true,
            'flex-width'  => true,
        )
    );

    add_theme_support(
        'html5',
        array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
    );

    add_theme_support(
        'woocommerce',
        array(
            'thumbnail_image_width' => 720,
            'single_image_width'    => 1100,
            'product_grid'          => array(
                'default_rows'    => 2,
                'min_rows'        => 1,
                'max_rows'        => 8,
                'default_columns' => 3,
                'min_columns'     => 1,
                'max_columns'     => 4,
            ),
        )
    );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    register_nav_menus(
        array(
            'primary' => __( 'Primary Navigation', 'persiano-dish' ),
            'footer'  => __( 'Footer Navigation', 'persiano-dish' ),
        )
    );
}
add_action( 'after_setup_theme', 'persiano_dish_setup' );

function persiano_dish_assets() {
    wp_enqueue_style( 'persiano-dish-style', get_stylesheet_uri(), array(), PERSIANO_DISH_VERSION );
    wp_enqueue_script( 'persiano-dish-theme', get_template_directory_uri() . '/assets/js/theme.js', array(), PERSIANO_DISH_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'persiano_dish_assets' );

function persiano_dish_customize_register( $wp_customize ) {
    $wp_customize->add_section(
        'persiano_home',
        array(
            'title'    => __( 'Persiano Dish Homepage', 'persiano-dish' ),
            'priority' => 30,
        )
    );

    $wp_customize->add_section(
        'persiano_branding',
        array(
            'title'    => __( 'Persiano Dish Branding', 'persiano-dish' ),
            'priority' => 31,
        )
    );

    $wp_customize->add_section(
        'persiano_contact',
        array(
            'title'    => __( 'Persiano Dish Contact', 'persiano-dish' ),
            'priority' => 32,
        )
    );

    $home_settings = array(
        'hero_kicker'      => array( 'label' => 'Hero Eyebrow', 'default' => 'Homemade Persian food · North & West Vancouver', 'sanitize' => 'sanitize_text_field' ),
        'hero_title'       => array( 'label' => 'Hero Heading', 'default' => "Persian food,\nmade with a little\nmore heart.", 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'hero_text'        => array( 'label' => 'Hero Description', 'default' => 'Prepared meals, pantry favourites, catering and gatherings — thoughtfully made in small batches.', 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'hero_note_title'  => array( 'label' => 'Hero Note Title', 'default' => 'Made in small batches', 'sanitize' => 'sanitize_text_field' ),
        'hero_note_text'   => array( 'label' => 'Hero Note Text', 'default' => 'A changing menu, a growing pantry, and food made with care.', 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'hero_image'       => array( 'label' => 'Hero Image', 'default' => '', 'sanitize' => 'absint', 'control' => 'media' ),
        'story_title'      => array( 'label' => 'Story Heading', 'default' => 'Food should tell a story.', 'sanitize' => 'sanitize_text_field' ),
        'story_text'       => array( 'label' => 'Story Text', 'default' => 'At Persiano Dish, familiar Persian flavours meet a home kitchen that cooks with care, curiosity and a respect for tradition.', 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'story_image'      => array( 'label' => 'Story Image', 'default' => '', 'sanitize' => 'absint', 'control' => 'media' ),
        'catering_title'   => array( 'label' => 'Catering Heading', 'default' => 'Bringing people together?', 'sanitize' => 'sanitize_text_field' ),
        'catering_text'    => array( 'label' => 'Catering Text', 'default' => 'From intimate family dinners to celebrations and private gatherings, Persiano Dish can create a menu around your table.', 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'catering_image'   => array( 'label' => 'Catering Image', 'default' => '', 'sanitize' => 'absint', 'control' => 'media' ),
    );

    foreach ( $home_settings as $id => $config ) {
        $wp_customize->add_setting(
            'persiano_' . $id,
            array(
                'default'           => $config['default'],
                'sanitize_callback' => $config['sanitize'],
            )
        );

        if ( isset( $config['control'] ) && 'media' === $config['control'] ) {
            $wp_customize->add_control(
                new WP_Customize_Media_Control(
                    $wp_customize,
                    'persiano_' . $id,
                    array(
                        'label'     => __( $config['label'], 'persiano-dish' ),
                        'section'   => 'persiano_home',
                        'mime_type' => 'image',
                    )
                )
            );
        } else {
            $wp_customize->add_control(
                'persiano_' . $id,
                array(
                    'label'   => __( $config['label'], 'persiano-dish' ),
                    'section' => 'persiano_home',
                    'type'    => isset( $config['type'] ) ? $config['type'] : 'text',
                )
            );
        }
    }

    $branding_settings = array(
        'header_logo' => array( 'label' => 'Header Logo', 'default' => '', 'sanitize' => 'absint', 'control' => 'media' ),
        'footer_logo' => array( 'label' => 'Footer Logo', 'default' => '', 'sanitize' => 'absint', 'control' => 'media' ),
        'footer_text' => array( 'label' => 'Footer Brand Text', 'default' => 'Small-batch Persian prepared food, pantry favourites, catering and gatherings in North & West Vancouver.', 'sanitize' => 'sanitize_textarea_field', 'type' => 'textarea' ),
        'footer_note' => array( 'label' => 'Footer Bottom Note', 'default' => 'Made in small batches in British Columbia.', 'sanitize' => 'sanitize_text_field' ),
    );

    foreach ( $branding_settings as $id => $config ) {
        $wp_customize->add_setting(
            'persiano_' . $id,
            array(
                'default'           => $config['default'],
                'sanitize_callback' => $config['sanitize'],
            )
        );

        if ( isset( $config['control'] ) && 'media' === $config['control'] ) {
            $wp_customize->add_control(
                new WP_Customize_Media_Control(
                    $wp_customize,
                    'persiano_' . $id,
                    array(
                        'label'     => __( $config['label'], 'persiano-dish' ),
                        'section'   => 'persiano_branding',
                        'mime_type' => 'image',
                    )
                )
            );
        } else {
            $wp_customize->add_control(
                'persiano_' . $id,
                array(
                    'label'   => __( $config['label'], 'persiano-dish' ),
                    'section' => 'persiano_branding',
                    'type'    => isset( $config['type'] ) ? $config['type'] : 'text',
                )
            );
        }
    }


    $contact_settings = array(
        'contact_email' => array( 'label' => 'Contact Email', 'default' => 'info@persianodish.com', 'sanitize' => 'sanitize_email' ),
        'contact_phone' => array( 'label' => 'Contact Phone', 'default' => '236-788-3330', 'sanitize' => 'sanitize_text_field' ),
        'whatsapp_url'  => array( 'label' => 'WhatsApp URL', 'default' => 'https://wa.me/12367883330', 'sanitize' => 'esc_url_raw' ),
        'instagram_url' => array( 'label' => 'Instagram URL', 'default' => 'https://www.instagram.com/persiano.dish/', 'sanitize' => 'esc_url_raw' ),
        'telegram_url'  => array( 'label' => 'Telegram URL', 'default' => '', 'sanitize' => 'esc_url_raw' ),
    );

    foreach ( $contact_settings as $id => $config ) {
        $wp_customize->add_setting(
            'persiano_' . $id,
            array(
                'default'           => $config['default'],
                'sanitize_callback' => $config['sanitize'],
            )
        );

        $wp_customize->add_control(
            'persiano_' . $id,
            array(
                'label'   => __( $config['label'], 'persiano-dish' ),
                'section' => 'persiano_contact',
                'type'    => 'text',
            )
        );
    }
}
add_action( 'customize_register', 'persiano_dish_customize_register' );


/**
 * Return a saved URL with a reliable fallback when an older Customizer value is blank.
 */
function persiano_dish_get_instagram_url() {
    $url = trim( (string) get_theme_mod( 'persiano_instagram_url', '' ) );
    return $url ? $url : 'https://www.instagram.com/persiano.dish/';
}

function persiano_dish_get_telegram_url() {
    return trim( (string) get_theme_mod( 'persiano_telegram_url', '' ) );
}

function persiano_dish_get_contact_email() {
    $email = sanitize_email( get_theme_mod( 'persiano_contact_email', '' ) );
    return $email ? $email : 'info@persianodish.com';
}

function persiano_dish_get_contact_phone() {
    $phone = trim( (string) get_theme_mod( 'persiano_contact_phone', '' ) );
    return $phone ? $phone : '236-788-3330';
}

function persiano_dish_get_whatsapp_url() {
    $url = trim( (string) get_theme_mod( 'persiano_whatsapp_url', '' ) );
    return $url ? $url : 'https://wa.me/12367883330';
}

/**
 * Render only WPForms embedded in a page body.
 *
 * This prevents legacy page-builder sections from leaking into the custom
 * Contact layout while keeping the existing form reusable.
 */
function persiano_dish_get_embedded_wpforms( $content ) {
    $output = '';

    if ( preg_match_all( '/\[wpforms\b[^\]]*\]/i', (string) $content, $matches ) ) {
        foreach ( array_unique( $matches[0] ) as $shortcode ) {
            $output .= do_shortcode( $shortcode );
        }
    }

    if ( ! $output && has_blocks( $content ) ) {
        $walk_blocks = static function( $blocks ) use ( &$walk_blocks, &$output ) {
            foreach ( $blocks as $block ) {
                if ( 'wpforms/form-selector' === $block['blockName'] ) {
                    $output .= render_block( $block );
                    continue;
                }
                if ( ! empty( $block['innerBlocks'] ) ) {
                    $walk_blocks( $block['innerBlocks'] );
                }
            }
        };
        $walk_blocks( parse_blocks( $content ) );
    }

    return $output;
}

function persiano_dish_get_page_url( $slug, $fallback = '/' ) {
    $page = get_page_by_path( $slug );

    if ( $page ) {
        return get_permalink( $page );
    }

    if ( '/' === $fallback ) {
        $fallback = '/' . trim( $slug, '/' ) . '/';
    }

    return home_url( $fallback );
}

function persiano_dish_get_shop_url() {
    if ( function_exists( 'wc_get_page_permalink' ) ) {
        $shop = wc_get_page_permalink( 'shop' );
        if ( $shop ) {
            return $shop;
        }
    }
    return home_url( '/shop/' );
}

function persiano_dish_get_category_products( $slug, $limit = 3 ) {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return new WP_Query();
    }

    return new WP_Query(
        array(
            'post_type'      => 'product',
            'posts_per_page' => absint( $limit ),
            'post_status'    => 'publish',
            'tax_query'      => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'slug',
                    'terms'    => sanitize_title( $slug ),
                ),
            ),
        )
    );
}

function persiano_dish_get_cart_url() {
    if ( function_exists( 'wc_get_page_id' ) ) {
        $page_id = wc_get_page_id( 'cart' );
        if ( $page_id > 0 && 'publish' === get_post_status( $page_id ) ) {
            return get_permalink( $page_id );
        }
    }

    $page = get_page_by_path( 'cart' );
    return $page ? get_permalink( $page ) : home_url( '/cart/' );
}

function persiano_dish_get_checkout_url() {
    if ( function_exists( 'wc_get_page_id' ) ) {
        $page_id = wc_get_page_id( 'checkout' );
        if ( $page_id > 0 && 'publish' === get_post_status( $page_id ) ) {
            return get_permalink( $page_id );
        }
    }

    $page = get_page_by_path( 'checkout' );
    return $page ? get_permalink( $page ) : home_url( '/checkout/' );
}

function persiano_dish_cart_count() {
    if ( function_exists( 'WC' ) && WC()->cart ) {
        return WC()->cart->get_cart_contents_count();
    }
    return 0;
}

function persiano_dish_cart_fragments( $fragments ) {
    ob_start();
    ?>
    <span class="pd-cart-count"><?php echo esc_html( persiano_dish_cart_count() ); ?></span>
    <?php
    $fragments['.pd-cart-count'] = ob_get_clean();
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'persiano_dish_cart_fragments' );

function persiano_dish_body_classes( $classes ) {
    if ( class_exists( 'WooCommerce' ) ) {
        $classes[] = 'pd-has-woocommerce';
    }
    return $classes;
}
add_filter( 'body_class', 'persiano_dish_body_classes' );

function persiano_dish_fallback_menu() {
    $items = array(
        'this-week'  => __( 'This Week', 'persiano-dish' ),
        'our-dishes' => __( 'Our Dishes', 'persiano-dish' ),
        'the-pantry' => __( 'The Pantry', 'persiano-dish' ),
        'catering'   => __( 'Catering', 'persiano-dish' ),
        'events'     => __( 'Events', 'persiano-dish' ),
        'our-story'  => __( 'Our Story', 'persiano-dish' ),
    );
    echo '<ul>';
    foreach ( $items as $slug => $label ) {
        printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( persiano_dish_get_page_url( $slug ) ), esc_html( $label ) );
    }
    echo '</ul>';
}

function persiano_dish_get_logo_id( $location = 'header' ) {
    $location = 'footer' === $location ? 'footer' : 'header';
    $theme_mod = 'persiano_' . $location . '_logo';
    $logo_id   = absint( get_theme_mod( $theme_mod ) );

    if ( $logo_id ) {
        return $logo_id;
    }

    if ( has_custom_logo() ) {
        return absint( get_theme_mod( 'custom_logo' ) );
    }

    return 0;
}

function persiano_dish_render_logo( $location = 'header' ) {
    $logo_id = persiano_dish_get_logo_id( $location );

    if ( $logo_id ) {
        echo wp_get_attachment_image( $logo_id, 'full', false, array( 'class' => 'pd-logo pd-logo--' . esc_attr( $location ) ) );
        return;
    }

    echo '<span class="pd-brand-text">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
}


/**
 * Return all published prepared-meal products for the permanent Our Dishes catalogue.
 * This intentionally does not depend on current stock or This Week placement.
 *
 * @param array<string,string> $filters Optional search/course/dietary/availability filters.
 * @return array<int,WC_Product>
 */
function persiano_dish_get_all_dishes( $filters = array() ) {
    if ( ! function_exists( 'wc_get_products' ) ) {
        return array();
    }

    $products = wc_get_products(
        array(
            'status'  => 'publish',
            'limit'   => -1,
            'orderby' => 'name',
            'order'   => 'ASC',
        )
    );

    $search       = isset( $filters['search'] ) ? trim( (string) $filters['search'] ) : '';
    $course       = isset( $filters['course'] ) ? sanitize_key( $filters['course'] ) : '';
    $dietary      = isset( $filters['dietary'] ) ? sanitize_key( $filters['dietary'] ) : '';
    $availability = isset( $filters['availability'] ) ? sanitize_key( $filters['availability'] ) : '';
    $result       = array();

    foreach ( $products as $product ) {
        if ( ! $product instanceof WC_Product ) {
            continue;
        }

        $details = function_exists( 'persiano_hub_get_product_details' ) ? persiano_hub_get_product_details( $product->get_id() ) : array();
        $is_dish = isset( $details['content_type'] ) && 'prepared_meal' === $details['content_type'];
        if ( ! $is_dish && empty( $details['show_this_week'] ) ) {
            continue;
        }

        if ( $search ) {
            $haystack = wp_strip_all_tags( $product->get_name() . ' ' . $product->get_short_description() . ' ' . $product->get_description() );
            if ( false === stripos( $haystack, $search ) ) {
                continue;
            }
        }

        if ( $course && ( empty( $details['course'] ) || $course !== $details['course'] ) ) {
            continue;
        }

        if ( $dietary && ( empty( $details['dietary'] ) || ! in_array( $dietary, $details['dietary'], true ) ) ) {
            continue;
        }

        if ( 'available_now' === $availability && ( ! $product->is_in_stock() || ! $product->is_purchasable() ) ) {
            continue;
        }

        if ( 'advance_order' === $availability && empty( $details['allow_advance_order'] ) ) {
            continue;
        }

        $result[] = $product;
    }

    return $result;
}

function persiano_dish_get_course_options() {
    if ( function_exists( 'persiano_hub_get_course_options' ) ) {
        return persiano_hub_get_course_options();
    }
    return array(
        ''        => __( 'All courses', 'persiano-dish' ),
        'starter' => __( 'Starter', 'persiano-dish' ),
        'snack'   => __( 'Snack & Small Plate', 'persiano-dish' ),
        'main'    => __( 'Main Dish', 'persiano-dish' ),
        'side'    => __( 'Side Dish', 'persiano-dish' ),
        'dessert' => __( 'Dessert & Sweet', 'persiano-dish' ),
        'bread'   => __( 'Bread', 'persiano-dish' ),
    );
}

function persiano_dish_get_filterable_dietary_options() {
    $all = function_exists( 'persiano_hub_get_dietary_options' ) ? persiano_hub_get_dietary_options() : array();
    $keys = array( 'vegetarian', 'vegan', 'gluten_free_recipe', 'dairy_free_recipe' );
    $result = array();
    foreach ( $keys as $key ) {
        if ( isset( $all[ $key ] ) ) {
            $result[ $key ] = $all[ $key ];
        }
    }
    return $result;
}

/**
 * Create the core Persiano Dish pages and product categories when missing.
 *
 * The theme provides page-{slug}.php templates, so no manual template assignment
 * is needed once the pages exist with the expected slugs.
 */
function persiano_dish_ensure_site_structure() {
    $setup_version = get_option( 'persiano_dish_setup_version', '0' );

    if ( version_compare( $setup_version, PERSIANO_DISH_VERSION, '>=' ) ) {
        return;
    }

    $pages = array(
        'this-week'  => __( 'This Week', 'persiano-dish' ),
        'our-dishes' => __( 'Our Dishes', 'persiano-dish' ),
        'the-pantry' => __( 'The Pantry', 'persiano-dish' ),
        'catering'   => __( 'Catering', 'persiano-dish' ),
        'events'     => __( 'Events', 'persiano-dish' ),
        'our-story'  => __( 'Our Story', 'persiano-dish' ),
        'contact'    => __( 'Contact', 'persiano-dish' ),
        'cart'       => __( 'Cart', 'persiano-dish' ),
        'checkout'   => __( 'Checkout', 'persiano-dish' ),
    );

    foreach ( $pages as $slug => $title ) {
        $existing = get_page_by_path( $slug );

        if ( ! $existing ) {
            $content = '';
            if ( 'cart' === $slug ) {
                $content = '[woocommerce_cart]';
            } elseif ( 'checkout' === $slug ) {
                $content = '[woocommerce_checkout]';
            }

            $page_id = wp_insert_post(
                array(
                    'post_title'   => $title,
                    'post_name'    => $slug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => $content,
                )
            );
            $existing = $page_id && ! is_wp_error( $page_id ) ? get_post( $page_id ) : null;
        }

        if ( $existing && class_exists( 'WooCommerce' ) ) {
            if ( 'cart' === $slug ) {
                if ( '' === trim( (string) $existing->post_content ) ) {
                    wp_update_post( array( 'ID' => $existing->ID, 'post_content' => '[woocommerce_cart]' ) );
                }
                update_option( 'woocommerce_cart_page_id', $existing->ID );
            } elseif ( 'checkout' === $slug ) {
                if ( '' === trim( (string) $existing->post_content ) ) {
                    wp_update_post( array( 'ID' => $existing->ID, 'post_content' => '[woocommerce_checkout]' ) );
                }
                update_option( 'woocommerce_checkout_page_id', $existing->ID );
            }
        }
    }

    if ( taxonomy_exists( 'product_cat' ) ) {
        $categories = array(
            'this-week' => __( 'This Week', 'persiano-dish' ),
            'pantry'    => __( 'Pantry', 'persiano-dish' ),
        );

        foreach ( $categories as $slug => $name ) {
            if ( ! term_exists( $slug, 'product_cat' ) ) {
                wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
            }
        }
    }

    update_option( 'persiano_dish_setup_version', PERSIANO_DISH_VERSION );
    flush_rewrite_rules( false );
}
add_action( 'admin_init', 'persiano_dish_ensure_site_structure' );
add_action( 'after_switch_theme', 'persiano_dish_ensure_site_structure' );

function persiano_dish_remove_woocommerce_sidebar() {
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
}
add_action( 'wp', 'persiano_dish_remove_woocommerce_sidebar' );


/**
 * Include Persiano products and public Persiano content in front-end search.
 */
function persiano_dish_expand_search_query( $query ) {
    if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
        return;
    }

    $post_types = array( 'post', 'page' );

    if ( post_type_exists( 'product' ) ) {
        $post_types[] = 'product';
    }
    if ( post_type_exists( 'persiano_update' ) ) {
        $post_types[] = 'persiano_update';
    }
    if ( post_type_exists( 'persiano_event' ) ) {
        $post_types[] = 'persiano_event';
    } elseif ( post_type_exists( 'event' ) ) {
        $post_types[] = 'event';
    }

    $query->set( 'post_type', array_values( array_unique( $post_types ) ) );
    $query->set( 'post_status', 'publish' );
}
add_action( 'pre_get_posts', 'persiano_dish_expand_search_query' );

/**
 * Render the compact global Persiano search shown below the main navigation.
 */
function persiano_dish_render_global_search() {
    ?>
    <div class="pd-global-search-bar" role="search">
        <div class="pd-shell">
            <form class="pd-global-search-form" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <label class="screen-reader-text" for="pd-site-search"><?php esc_html_e( 'Search Persiano Dish', 'persiano-dish' ); ?></label>
                <span class="pd-global-search-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" focusable="false"><circle cx="10.7" cy="10.7" r="6.4" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="m15.4 15.4 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                </span>
                <input id="pd-site-search" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search dishes, pantry items, menus and updates…', 'persiano-dish' ); ?>" autocomplete="off">
                <button type="submit"><?php esc_html_e( 'Search', 'persiano-dish' ); ?></button>
            </form>
        </div>
    </div>
    <?php
}
