<?php
/**
 * Template Name: Contact
 *
 * @package Persiano_Dish
 */
get_header();

$instagram   = persiano_dish_get_instagram_url();
$telegram    = persiano_dish_get_telegram_url();
$email       = persiano_dish_get_contact_email();
$phone       = persiano_dish_get_contact_phone();
$whatsapp    = persiano_dish_get_whatsapp_url();
$page_content = '';
$form_markup  = '';

while ( have_posts() ) {
    the_post();
    $page_content = get_the_content();
    $form_markup  = persiano_dish_get_embedded_wpforms( $page_content );
}
?>
<section class="pd-page-hero pd-page-hero--split pd-contact-hero">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Get in touch', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'Let’s talk food.', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-page-hero-aside">
            <p class="pd-lead"><?php esc_html_e( 'Questions about an order, catering, pantry products or an upcoming event? Reach out and we’ll point you in the right direction.', 'persiano-dish' ); ?></p>
        </div>
    </div>
</section>

<section class="pd-section pd-contact-section">
    <div class="pd-shell pd-contact-layout pd-contact-layout--refined">
        <div class="pd-contact-details">
            <div class="pd-kicker"><?php esc_html_e( 'Contact Persiano', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'Choose the easiest way to reach us.', 'persiano-dish' ); ?></h2>
            <p class="pd-lead pd-contact-intro"><?php esc_html_e( 'For general questions, custom requests and order support, use whichever channel works best for you.', 'persiano-dish' ); ?></p>

            <div class="pd-contact-method-grid">
                <?php if ( $email ) : ?>
                    <a class="pd-contact-method" href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>">
                        <span><?php esc_html_e( 'Email', 'persiano-dish' ); ?></span>
                        <strong><?php echo esc_html( antispambot( $email ) ); ?></strong>
                        <small><?php esc_html_e( 'Best for detailed questions', 'persiano-dish' ); ?></small>
                    </a>
                <?php endif; ?>

                <?php if ( $phone ) : ?>
                    <a class="pd-contact-method" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>">
                        <span><?php esc_html_e( 'Phone', 'persiano-dish' ); ?></span>
                        <strong><?php echo esc_html( $phone ); ?></strong>
                        <small><?php esc_html_e( 'Call or text', 'persiano-dish' ); ?></small>
                    </a>
                <?php endif; ?>

                <?php if ( $whatsapp ) : ?>
                    <a class="pd-contact-method" href="<?php echo esc_url( $whatsapp ); ?>" target="_blank" rel="noopener">
                        <span><?php esc_html_e( 'WhatsApp', 'persiano-dish' ); ?></span>
                        <strong><?php esc_html_e( 'Chat with Persiano', 'persiano-dish' ); ?></strong>
                        <small><?php esc_html_e( 'Quick messages and questions', 'persiano-dish' ); ?></small>
                    </a>
                <?php endif; ?>

                <?php if ( $instagram ) : ?>
                    <a class="pd-contact-method" href="<?php echo esc_url( $instagram ); ?>" target="_blank" rel="noopener">
                        <span><?php esc_html_e( 'Instagram', 'persiano-dish' ); ?></span>
                        <strong>@persiano.dish</strong>
                        <small><?php esc_html_e( 'Follow menus and new releases', 'persiano-dish' ); ?></small>
                    </a>
                <?php endif; ?>

                <?php if ( $telegram ) : ?>
                    <a class="pd-contact-method" href="<?php echo esc_url( $telegram ); ?>" target="_blank" rel="noopener">
                        <span><?php esc_html_e( 'Telegram', 'persiano-dish' ); ?></span>
                        <strong><?php esc_html_e( 'Open Persiano on Telegram', 'persiano-dish' ); ?></strong>
                        <small><?php esc_html_e( 'Updates and direct messages', 'persiano-dish' ); ?></small>
                    </a>
                <?php endif; ?>
            </div>

            <div class="pd-contact-note">
                <strong><?php esc_html_e( 'Ordering prepared meals?', 'persiano-dish' ); ?></strong>
                <p><?php esc_html_e( 'For the fastest ordering experience, use the current menu and checkout rather than sending an order through the contact form.', 'persiano-dish' ); ?></p>
                <a href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'View This Week', 'persiano-dish' ); ?> →</a>
            </div>
        </div>

        <div class="pd-contact-form-wrap">
            <div class="pd-kicker"><?php esc_html_e( 'Send a message', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'Tell us how we can help.', 'persiano-dish' ); ?></h2>
            <div class="pd-form-panel pd-form-panel--light">
                <?php if ( $form_markup ) : ?>
                    <?php echo $form_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php else : ?>
                    <div class="pd-form-empty">
                        <h3><?php esc_html_e( 'Contact form coming soon.', 'persiano-dish' ); ?></h3>
                        <p><?php esc_html_e( 'You can still reach Persiano Dish directly by email, phone, WhatsApp, Instagram or Telegram.', 'persiano-dish' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>
