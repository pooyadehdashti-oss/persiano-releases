<?php
/**
 * Cart page.
 *
 * @package Persiano_Dish
 */
get_header();
?>
<section class="pd-commerce-hero">
    <div class="pd-shell pd-commerce-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Your order', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'Review your cart.', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-commerce-hero-copy">
            <p><?php esc_html_e( 'Check quantities and product details before continuing to checkout. Pickup, local delivery and shipping options are shown based on the items in your order and your address.', 'persiano-dish' ); ?></p>
            <div class="pd-inline-notes"><span><?php esc_html_e( 'Secure checkout', 'persiano-dish' ); ?></span><span><?php esc_html_e( 'Square payment', 'persiano-dish' ); ?></span><span><?php esc_html_e( 'Order confirmation', 'persiano-dish' ); ?></span></div>
        </div>
    </div>
</section>

<section class="pd-commerce-section">
    <div class="pd-shell pd-commerce-shell">
        <?php while ( have_posts() ) : the_post(); ?>
            <div class="pd-commerce-content pd-cart-content">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</section>

<section class="pd-commerce-help">
    <div class="pd-shell pd-commerce-help-grid">
        <article>
            <span>01</span>
            <h3><?php esc_html_e( 'Prepared meals', 'persiano-dish' ); ?></h3>
            <p><?php esc_html_e( 'Availability and order deadlines are shown with each meal. Limited batches can sell out.', 'persiano-dish' ); ?></p>
        </article>
        <article>
            <span>02</span>
            <h3><?php esc_html_e( 'Choose fulfilment', 'persiano-dish' ); ?></h3>
            <p><?php esc_html_e( 'Available pickup, local delivery or shipping methods are calculated during checkout.', 'persiano-dish' ); ?></p>
        </article>
        <article>
            <span>03</span>
            <h3><?php esc_html_e( 'Pay securely', 'persiano-dish' ); ?></h3>
            <p><?php esc_html_e( 'Complete payment through the payment methods enabled for Persiano Dish, including Square when available.', 'persiano-dish' ); ?></p>
        </article>
    </div>
</section>
<?php get_footer(); ?>
