<?php
/**
 * Search results.
 *
 * @package Persiano_Dish
 */
get_header();
$search_term = get_search_query();
?>
<section class="pd-page-hero pd-page-hero--compact">
    <div class="pd-shell">
        <div class="pd-kicker"><?php esc_html_e( 'Search Persiano Dish', 'persiano-dish' ); ?></div>
        <h1><?php echo esc_html( $search_term ? sprintf( __( 'Results for “%s”', 'persiano-dish' ), $search_term ) : __( 'Search results', 'persiano-dish' ) ); ?></h1>
        <p class="pd-lead"><?php esc_html_e( 'Browse matching dishes, Pantry products, pages and Persiano updates.', 'persiano-dish' ); ?></p>
    </div>
</section>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <?php if ( have_posts() ) : ?>
            <div class="pd-search-results-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php if ( 'product' === get_post_type() && function_exists( 'wc_get_product' ) ) : ?>
                        <?php $product = wc_get_product( get_the_ID() ); ?>
                        <?php if ( $product ) : ?>
                            <?php get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => __( 'Product', 'persiano-dish' ) ) ); ?>
                        <?php endif; ?>
                    <?php else : ?>
                        <article class="pd-search-result-card">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a class="pd-search-result-image" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a>
                            <?php endif; ?>
                            <div class="pd-search-result-body">
                                <div class="pd-kicker"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ?? __( 'Content', 'persiano-dish' ) ); ?></div>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p>
                                <a class="pd-text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View', 'persiano-dish' ); ?> →</a>
                            </div>
                        </article>
                    <?php endif; ?>
                <?php endwhile; ?>
            </div>
            <div class="pd-search-pagination"><?php the_posts_pagination(); ?></div>
        <?php else : ?>
            <div class="pd-empty-state">
                <div class="pd-empty-state-mark">P</div>
                <div>
                    <h3><?php esc_html_e( 'No matches found.', 'persiano-dish' ); ?></h3>
                    <p><?php esc_html_e( 'Try another dish name, ingredient, Pantry item or menu keyword.', 'persiano-dish' ); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php get_footer(); ?>
