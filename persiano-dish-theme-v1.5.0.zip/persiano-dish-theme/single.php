<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>
<article>
    <section class="pd-page-hero">
        <div class="pd-shell">
            <div class="pd-kicker"><?php echo esc_html( get_the_date() ); ?></div>
            <h1><?php the_title(); ?></h1>
        </div>
    </section>
    <div class="pd-narrow pd-page-content">
        <?php if ( has_post_thumbnail() ) : ?><div style="margin-bottom:36px;"><?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:22px;width:100%;' ) ); ?></div><?php endif; ?>
        <?php the_content(); ?>
    </div>
</article>
<?php endwhile; ?>
<?php get_footer(); ?>
