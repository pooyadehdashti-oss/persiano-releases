<?php
/**
 * Template Name: Events
 *
 * @package Persiano_Dish
 */
get_header();
$post_type = post_type_exists( 'persiano_event' ) ? 'persiano_event' : ( post_type_exists( 'event' ) ? 'event' : '' );
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div><div class="pd-kicker"><?php esc_html_e( 'Around the Persiano table', 'persiano-dish' ); ?></div><h1><?php esc_html_e( 'Events & experiences', 'persiano-dish' ); ?></h1></div>
        <div class="pd-page-hero-aside"><p class="pd-lead"><?php esc_html_e( 'Tastings, pop-ups and special gatherings — a place to discover what is happening beyond the weekly menu.', 'persiano-dish' ); ?></p></div>
    </div>
</section>

<?php while ( have_posts() ) : the_post(); ?>
    <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
        <section class="pd-section pd-section--compact"><div class="pd-shell"><div class="pd-rich-intro"><?php the_content(); ?></div></div></section>
    <?php endif; ?>
<?php endwhile; ?>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top"><div><div class="pd-kicker"><?php esc_html_e( 'Upcoming', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'Join us at the next table.', 'persiano-dish' ); ?></h2></div></div>
        <?php if ( $post_type ) : ?>
            <?php $events = new WP_Query( array( 'post_type' => $post_type, 'posts_per_page' => 20, 'post_status' => 'publish' ) ); ?>
            <?php if ( $events->have_posts() ) : ?>
                <div class="pd-event-list">
                    <?php while ( $events->have_posts() ) : $events->the_post(); ?>
                        <article class="pd-event-card">
                            <div class="pd-event-date"><span><?php echo esc_html( get_the_date( 'M' ) ); ?></span><strong><?php echo esc_html( get_the_date( 'j' ) ); ?></strong><small><?php echo esc_html( get_the_date( 'Y' ) ); ?></small></div>
                            <div class="pd-event-card-content"><h3><?php the_title(); ?></h3><p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p></div>
                            <a class="pd-btn pd-btn--secondary" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View Event', 'persiano-dish' ); ?></a>
                        </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php else : ?>
                <div class="pd-empty-state"><div class="pd-empty-state-mark">P</div><div><h3><?php esc_html_e( 'Nothing is scheduled right now.', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'When the next Persiano tasting, pop-up or special event is announced, you will find it here.', 'persiano-dish' ); ?></p></div></div>
            <?php endif; ?>
        <?php else : ?>
            <div class="pd-empty-state"><div class="pd-empty-state-mark">P</div><div><h3><?php esc_html_e( 'Nothing is scheduled right now.', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'The future Persiano Hub event system will publish upcoming events here automatically.', 'persiano-dish' ); ?></p></div></div>
        <?php endif; ?>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell pd-event-note">
        <div><div class="pd-kicker"><?php esc_html_e( 'Hosting something yourself?', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'Persiano can come to your table too.', 'persiano-dish' ); ?></h2><p class="pd-lead"><?php esc_html_e( 'For private gatherings and larger food orders, explore our catering options.', 'persiano-dish' ); ?></p></div>
        <a class="pd-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'catering' ) ); ?>"><?php esc_html_e( 'Explore Catering', 'persiano-dish' ); ?></a>
    </div>
</section>
<?php get_footer(); ?>
