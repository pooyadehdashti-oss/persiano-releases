<?php
/**
 * Front page template.
 *
 * @package Persiano_Dish
 */
get_header();

$hero_image_id     = absint( get_theme_mod( 'persiano_hero_image' ) );
$story_image_id    = absint( get_theme_mod( 'persiano_story_image' ) );
$catering_image_id = absint( get_theme_mod( 'persiano_catering_image' ) );
$this_week         = persiano_dish_get_category_products( 'this-week', 3 );
$pantry            = persiano_dish_get_category_products( 'pantry', 4 );
$hero_title        = (string) get_theme_mod( 'persiano_hero_title', "Persian food,\nmade with a little\nmore heart." );
?>

<section class="pd-hero">
    <div class="pd-shell pd-hero-grid">
        <div class="pd-hero-copy">
            <div class="pd-kicker"><?php echo esc_html( get_theme_mod( 'persiano_hero_kicker', 'Homemade Persian food · North & West Vancouver' ) ); ?></div>
            <h1><?php echo nl2br( esc_html( $hero_title ) ); ?></h1>
            <p><?php echo esc_html( get_theme_mod( 'persiano_hero_text', 'Prepared meals, pantry favourites, catering and gatherings — thoughtfully made in small batches.' ) ); ?></p>
            <div class="pd-actions">
                <a class="pd-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'Explore This Week', 'persiano-dish' ); ?></a>
                <a class="pd-btn pd-btn--secondary" href="<?php echo esc_url( persiano_dish_get_page_url( 'the-pantry', '/shop/' ) ); ?>"><?php esc_html_e( 'Shop the Pantry', 'persiano-dish' ); ?></a>
            </div>
            <div class="pd-hero-proof">
                <strong><?php echo esc_html( get_theme_mod( 'persiano_hero_note_title', 'Made in small batches' ) ); ?></strong>
                <span><?php echo esc_html( get_theme_mod( 'persiano_hero_note_text', 'A changing menu, a growing pantry, and food made with care.' ) ); ?></span>
            </div>
        </div>
        <div class="pd-hero-media">
            <div class="pd-hero-image">
                <?php if ( $hero_image_id ) : ?>
                    <?php echo wp_get_attachment_image( $hero_image_id, 'full', false, array( 'loading' => 'eager' ) ); ?>
                <?php else : ?>
                    <div class="pd-media-placeholder">Upload a hero food image in Appearance → Customize → Persiano Dish Homepage.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Prepared for you', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'This Week at Persiano', 'persiano-dish' ); ?></h2>
            </div>
            <p class="pd-lead"><?php esc_html_e( 'Something different is always cooking. Pre-order the dishes you want before the batch is gone.', 'persiano-dish' ); ?></p>
        </div>

        <?php if ( $this_week->have_posts() ) : ?>
            <div class="pd-product-grid">
                <?php while ( $this_week->have_posts() ) : $this_week->the_post(); global $product; ?>
                    <?php get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => __( 'This Week', 'persiano-dish' ) ) ); ?>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <p class="pd-lead"><?php esc_html_e( 'The next menu is coming soon. Follow Persiano Dish for the latest small-batch releases.', 'persiano-dish' ); ?></p>
        <?php endif; ?>

        <div style="margin-top:34px;">
            <a class="pd-btn pd-btn--secondary" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'See the Full Menu', 'persiano-dish' ); ?></a>
        </div>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell">
        <div class="pd-section-head">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'For your kitchen', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'From the Persiano Pantry', 'persiano-dish' ); ?></h2>
            </div>
            <p class="pd-lead"><?php esc_html_e( 'Persian kitchen staples, preserves and ready-to-use favourites made in small batches.', 'persiano-dish' ); ?></p>
        </div>

        <?php if ( $pantry->have_posts() ) : ?>
            <div class="pd-product-grid">
                <?php while ( $pantry->have_posts() ) : $pantry->the_post(); global $product; ?>
                    <?php get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => __( 'The Pantry', 'persiano-dish' ) ) ); ?>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <p class="pd-lead"><?php esc_html_e( 'New pantry favourites are on the way. Check back soon for the next small-batch release.', 'persiano-dish' ); ?></p>
        <?php endif; ?>

        <div style="margin-top:34px;">
            <a class="pd-btn pd-btn--secondary" href="<?php echo esc_url( persiano_dish_get_page_url( 'the-pantry', '/shop/' ) ); ?>"><?php esc_html_e( 'Shop the Pantry', 'persiano-dish' ); ?></a>
        </div>
    </div>
</section>

<section class="pd-section pd-section--dark">
    <div class="pd-shell pd-story-grid">
        <div class="pd-story-media">
            <?php if ( $story_image_id ) : ?>
                <?php echo wp_get_attachment_image( $story_image_id, 'large' ); ?>
            <?php else : ?>
                <div class="pd-media-placeholder pd-media-placeholder--dark">Add an editorial kitchen or ingredient image in the Customizer.</div>
            <?php endif; ?>
            <div class="pd-pattern-card" aria-hidden="true"></div>
        </div>
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'The Persiano approach', 'persiano-dish' ); ?></div>
            <h2><?php echo esc_html( get_theme_mod( 'persiano_story_title', 'Food should tell a story.' ) ); ?></h2>
            <p class="pd-lead"><?php echo esc_html( get_theme_mod( 'persiano_story_text', 'At Persiano Dish, familiar Persian flavours meet a home kitchen that cooks with care, curiosity and a respect for tradition.' ) ); ?></p>
            <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'our-story' ) ); ?>"><?php esc_html_e( 'Our Story', 'persiano-dish' ); ?></a>
        </div>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell">
        <div class="pd-catering-card">
            <?php if ( $catering_image_id ) : ?>
                <?php echo wp_get_attachment_image( $catering_image_id, 'full' ); ?>
            <?php endif; ?>
            <div class="pd-catering-content">
                <div class="pd-kicker"><?php esc_html_e( 'Catering & private gatherings', 'persiano-dish' ); ?></div>
                <h2><?php echo esc_html( get_theme_mod( 'persiano_catering_title', 'Bringing people together?' ) ); ?></h2>
                <p><?php echo esc_html( get_theme_mod( 'persiano_catering_text', 'From intimate family dinners to celebrations and private gatherings, Persiano Dish can create a menu around your table.' ) ); ?></p>
                <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'catering' ) ); ?>"><?php esc_html_e( 'Explore Catering', 'persiano-dish' ); ?></a>
            </div>
        </div>
    </div>
</section>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Kind words', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'What people are saying', 'persiano-dish' ); ?></h2>
            </div>
        </div>
        <?php
        $reviews_rendered = false;
        if ( class_exists( 'Persiano_Hub_Google_Reviews' ) ) {
            $reviews_rendered = Persiano_Hub_Google_Reviews::render_reviews(
                array(
                    'limit'         => 3,
                    'featured_only' => true,
                )
            );
        }
        if ( ! $reviews_rendered ) :
        ?>
            <div class="pd-reviews">
                <article class="pd-review"><div class="pd-stars">★★★★★</div><blockquote><?php esc_html_e( 'The food stands out because of its quality, freshness and taste.', 'persiano-dish' ); ?></blockquote><cite><?php esc_html_e( 'Persiano Dish customer', 'persiano-dish' ); ?></cite></article>
                <article class="pd-review"><div class="pd-stars">★★★★★</div><blockquote><?php esc_html_e( 'Every single guest loved it — thoughtful, reliable and beautifully prepared.', 'persiano-dish' ); ?></blockquote><cite><?php esc_html_e( 'Catering customer', 'persiano-dish' ); ?></cite></article>
                <article class="pd-review"><div class="pd-stars">★★★★★</div><blockquote><?php esc_html_e( 'Homemade food that makes you want to become a regular customer.', 'persiano-dish' ); ?></blockquote><cite><?php esc_html_e( 'Persiano Dish customer', 'persiano-dish' ); ?></cite></article>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
