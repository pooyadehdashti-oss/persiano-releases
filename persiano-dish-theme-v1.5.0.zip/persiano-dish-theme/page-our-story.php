<?php
/**
 * Template Name: Our Story
 *
 * @package Persiano_Dish
 */
get_header();
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div><div class="pd-kicker"><?php esc_html_e( 'Our story', 'persiano-dish' ); ?></div><h1><?php esc_html_e( 'Persian food with a home-kitchen soul.', 'persiano-dish' ); ?></h1></div>
        <div class="pd-page-hero-aside"><p class="pd-lead"><?php esc_html_e( 'Persiano Dish is built around familiar Persian flavours, thoughtful cooking and the simple pleasure of sharing good food.', 'persiano-dish' ); ?></p></div>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell pd-story-page-layout">
        <aside class="pd-story-page-aside"><div class="pd-kicker"><?php esc_html_e( 'Persiano Dish', 'persiano-dish' ); ?></div><blockquote><?php esc_html_e( 'A changing menu, a growing pantry and food made in small batches with care.', 'persiano-dish' ); ?></blockquote></aside>
        <div class="pd-story-page-content">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
                    <?php the_content(); ?>
                <?php else : ?>
                    <h2><?php esc_html_e( 'Made personally, not mass-produced.', 'persiano-dish' ); ?></h2>
                    <p><?php esc_html_e( 'Persiano Dish is a small food business focused on prepared Persian meals, pantry products, catering and special gatherings. The menu can change from week to week, making room for traditional favourites, seasonal ideas and dishes worth sharing.', 'persiano-dish' ); ?></p>
                    <p><?php esc_html_e( 'The idea is simple: make food with the attention of a home kitchen while giving customers an easier way to bring Persian flavours to their own table.', 'persiano-dish' ); ?></p>
                <?php endif; ?>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top"><div><div class="pd-kicker"><?php esc_html_e( 'What guides us', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'The Persiano approach.', 'persiano-dish' ); ?></h2></div></div>
        <div class="pd-value-grid">
            <article><span>01</span><h3><?php esc_html_e( 'Small-batch cooking', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Cooking in manageable quantities helps keep the focus on freshness, consistency and the details of each dish.', 'persiano-dish' ); ?></p></article>
            <article><span>02</span><h3><?php esc_html_e( 'Persian flavours', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'The food is rooted in Persian cooking while leaving room for seasonal dishes, personal favourites and new ideas.', 'persiano-dish' ); ?></p></article>
            <article><span>03</span><h3><?php esc_html_e( 'A personal experience', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Persiano is intentionally small enough for orders, questions and gatherings to receive direct attention.', 'persiano-dish' ); ?></p></article>
        </div>
    </div>
</section>

<section class="pd-callout-band">
    <div class="pd-shell pd-callout-band-inner">
        <div><div class="pd-kicker"><?php esc_html_e( 'Come to the table', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'See what Persiano is cooking now.', 'persiano-dish' ); ?></h2></div>
        <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'Explore This Week', 'persiano-dish' ); ?></a>
    </div>
</section>
<?php get_footer(); ?>
