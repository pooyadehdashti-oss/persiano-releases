<?php
/**
 * Site footer.
 *
 * @package Persiano_Dish
 */
?>
</main>
<?php if ( function_exists( 'persiano_hub_render_newsletter_form' ) ) : ?>
<section class="pd-footer-newsletter">
    <div class="pd-shell">
        <?php persiano_hub_render_newsletter_form( array( 'source' => 'footer', 'compact' => true ) ); ?>
    </div>
</section>
<?php endif; ?>
<footer class="pd-footer">
    <div class="pd-shell">
        <div class="pd-footer-grid">
            <div class="pd-footer-brand">
                <a class="pd-footer-brand-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    <?php persiano_dish_render_logo( 'footer' ); ?>
                </a>
                <p><?php echo esc_html( get_theme_mod( 'persiano_footer_text', 'Small-batch Persian prepared food, pantry favourites, catering and gatherings in North & West Vancouver.' ) ); ?></p>
            </div>
            <div>
                <h4><?php esc_html_e( 'Explore', 'persiano-dish' ); ?></h4>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'footer',
                        'container'      => false,
                        'fallback_cb'    => 'persiano_dish_fallback_menu',
                        'depth'          => 1,
                    )
                );
                ?>
            </div>
            <div>
                <h4><?php esc_html_e( 'Order', 'persiano-dish' ); ?></h4>
                <ul>
                    <li><a href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'This Week', 'persiano-dish' ); ?></a></li>
                    <li><a href="<?php echo esc_url( persiano_dish_get_page_url( 'our-dishes' ) ); ?>"><?php esc_html_e( 'Our Dishes', 'persiano-dish' ); ?></a></li>
                    <li><a href="<?php echo esc_url( persiano_dish_get_page_url( 'the-pantry', '/shop/' ) ); ?>"><?php esc_html_e( 'The Pantry', 'persiano-dish' ); ?></a></li>
                    <li><a href="<?php echo esc_url( persiano_dish_get_page_url( 'catering' ) ); ?>"><?php esc_html_e( 'Catering', 'persiano-dish' ); ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?php esc_html_e( 'Follow', 'persiano-dish' ); ?></h4>
                <ul>
                    <li><a href="<?php echo esc_url( persiano_dish_get_instagram_url() ); ?>" target="_blank" rel="noopener">Instagram</a></li>
                    <?php if ( persiano_dish_get_telegram_url() ) : ?>
                        <li><a href="<?php echo esc_url( persiano_dish_get_telegram_url() ); ?>" target="_blank" rel="noopener">Telegram</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo esc_url( persiano_dish_get_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact', 'persiano-dish' ); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="pd-footer-bottom">
            <span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>.</span>
            <span><?php echo esc_html( get_theme_mod( 'persiano_footer_note', 'Made in small batches in British Columbia.' ) ); ?></span>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
