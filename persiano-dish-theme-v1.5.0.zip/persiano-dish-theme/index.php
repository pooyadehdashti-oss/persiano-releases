<?php get_header(); ?>
<section class="pd-page-hero"><div class="pd-shell"><div class="pd-kicker"><?php bloginfo( 'name' ); ?></div><h1><?php esc_html_e( 'Stories & Updates', 'persiano-dish' ); ?></h1></div></section>
<section class="pd-section"><div class="pd-shell">
<?php if ( have_posts() ) : ?>
    <div class="pd-product-grid">
    <?php while ( have_posts() ) : the_post(); ?>
        <article class="pd-product-card">
            <?php if ( has_post_thumbnail() ) : ?><a class="pd-product-image" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a><?php endif; ?>
            <div class="pd-product-body"><div class="pd-product-meta"><span class="pd-badge"><?php echo esc_html( get_the_date() ); ?></span></div><h3><a href="<?php the_permalink(); ?>" style="text-decoration:none;"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p></div>
        </article>
    <?php endwhile; ?>
    </div>
    <div style="margin-top:40px;"><?php the_posts_pagination(); ?></div>
<?php else : ?><p><?php esc_html_e( 'Nothing has been published yet.', 'persiano-dish' ); ?></p><?php endif; ?>
</div></section>
<?php get_footer(); ?>
