# Persiano Dish Theme

A bespoke WordPress/WooCommerce theme for Persiano Dish.

## Version 1.2.1 page system

The main customer pages now use dedicated Persiano layouts rather than generic WordPress content pages:

- This Week — prepared-meal ordering journey, product grid, ordering steps
- The Pantry — pantry shop, fulfilment guidance, product grid
- Catering — service types, process, inquiry form area
- Events — upcoming-event system with a polished empty state until Persiano Hub is connected
- Our Story — editorial story layout and brand values
- Contact — contact methods and a dedicated form panel
- WooCommerce catalog — custom Persiano shop/category heading and product presentation

## Intended site structure

The theme now creates these pages automatically when they are missing. Because WordPress uses the matching `page-{slug}.php` file automatically, manual template assignment is not required:

- This Week — `this-week` — Template: This Week
- The Pantry — `the-pantry` — Template: The Pantry
- Catering — `catering` — Template: Catering
- Events — `events` — Template: Events
- Our Story — `our-story` — Template: Our Story
- Contact — `contact` — Template: Contact

## WooCommerce categories

The theme also creates these WooCommerce product categories automatically when WooCommerce is active:

- This Week — slug `this-week`
- Pantry — slug `pantry`

The homepage and custom page templates automatically pull products from these categories.

## Forms

The Catering and Contact templates automatically style page content as a form panel. Add a WPForms block or shortcode directly to the corresponding WordPress page.

- Put the general contact form on the Contact page.
- Put the catering inquiry form on the Catering page.

No form ID is hard-coded into the theme.

## Homepage setup

1. Activate the theme.
2. Go to Appearance → Customize → Persiano Dish Homepage.
3. Upload hero, editorial/story, and catering images.
4. Go to Appearance → Customize → Persiano Dish Branding for header/footer logos.
5. Create a primary menu using: This Week, The Pantry, Catering, Events, Our Story.
6. Assign the homepage under Settings → Reading. The theme's `front-page.php` will render the custom homepage.

## Commerce

The theme declares WooCommerce support and styles the product grid, product pages, cart and checkout. Payment gateway functionality remains in WooCommerce extensions such as Square.

## Future Persiano Hub compatibility

The theme intentionally does not register custom post types or social publishing logic. Those belong in the future Persiano Hub plugin, so changing the theme will never remove business data or integrations.

## 1.4.0
- Added the Our Dishes catalogue with search, course, dietary and availability filters.
- Added advance-order discovery and dietary/variation labels to product cards.
- Added tax-included price cues and navigation links to the full catalogue.


## 1.5.0
- Adds a global search bar across Persiano pages.
- Search includes WooCommerce products plus public Persiano content.
- Adds a dedicated search results layout.
