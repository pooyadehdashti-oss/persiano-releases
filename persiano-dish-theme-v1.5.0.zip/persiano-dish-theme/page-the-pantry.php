<?php
/**
 * Template Name: The Pantry
 *
 * Pantry shop page.
 *
 * @package Persiano_Dish
 */
get_header();
$query = persiano_dish_get_category_products( 'pantry', 48 );
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Made for your kitchen', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'The Persiano Pantry', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-page-hero-aside">
            <p class="pd-lead"><?php esc_html_e( 'Small-batch Persian kitchen favourites — from preserves and pickles to prepared ingredients and cooking bases.', 'persiano-dish' ); ?></p>
            <div class="pd-inline-notes">
                <span><?php esc_html_e( 'Small-batch', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Local fulfilment', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Shipping where available', 'persiano-dish' ); ?></span>
            </div>
        </div>
    </div>
</section>

<?php while ( have_posts() ) : the_post(); ?>
    <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
        <section class="pd-section pd-section--compact"><div class="pd-shell"><div class="pd-rich-intro"><?php the_content(); ?></div></div></section>
    <?php endif; ?>
<?php endwhile; ?>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Shop the pantry', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'Made in small batches.', 'persiano-dish' ); ?></h2>
            </div>
            <p class="pd-lead"><?php esc_html_e( 'Each product page shows the available pickup, delivery or shipping options for that item.', 'persiano-dish' ); ?></p>
        </div>

        <?php if ( $query->have_posts() ) : ?>
            <div class="pd-product-grid pd-product-grid--four">
                <?php while ( $query->have_posts() ) : $query->the_post(); global $product; ?>
                    <?php get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => __( 'Pantry', 'persiano-dish' ) ) ); ?>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <div class="pd-empty-state">
                <div class="pd-empty-state-mark">P</div>
                <div><h3><?php esc_html_e( 'The pantry is being stocked.', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Pantry products will appear here as they become available.', 'persiano-dish' ); ?></p></div>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell">
        <div class="pd-info-grid">
            <article class="pd-info-card"><div class="pd-info-card-label"><?php esc_html_e( 'Local orders', 'persiano-dish' ); ?></div><h3><?php esc_html_e( 'Pickup & local delivery', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Available local fulfilment options are calculated and displayed during checkout.', 'persiano-dish' ); ?></p></article>
            <article class="pd-info-card"><div class="pd-info-card-label"><?php esc_html_e( 'Pantry shipping', 'persiano-dish' ); ?></div><h3><?php esc_html_e( 'Shipping by product', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Only products configured as shippable will offer shipping at checkout.', 'persiano-dish' ); ?></p></article>
            <article class="pd-info-card"><div class="pd-info-card-label"><?php esc_html_e( 'Need help?', 'persiano-dish' ); ?></div><h3><?php esc_html_e( 'Ask before ordering', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'For product, ingredient or fulfilment questions, contact Persiano Dish before placing your order.', 'persiano-dish' ); ?></p><a href="<?php echo esc_url( persiano_dish_get_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact us', 'persiano-dish' ); ?> →</a></article>
        </div>
    </div>
</section>

<section class="pd-callout-band">
    <div class="pd-shell pd-callout-band-inner">
        <div><div class="pd-kicker"><?php esc_html_e( 'Ready to eat', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'See what we’re cooking this week.', 'persiano-dish' ); ?></h2></div>
        <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week' ) ); ?>"><?php esc_html_e( 'Explore This Week', 'persiano-dish' ); ?></a>
    </div>
</section>
<?php get_footer(); ?>
