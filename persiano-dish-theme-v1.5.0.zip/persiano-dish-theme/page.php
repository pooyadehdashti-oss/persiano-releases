<?php
/**
 * Default page template.
 *
 * @package Persiano_Dish
 */
get_header();
while ( have_posts() ) : the_post();
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php bloginfo( 'name' ); ?></div>
            <h1><?php the_title(); ?></h1>
        </div>
        <?php if ( has_excerpt() ) : ?>
            <div class="pd-page-hero-aside"><p class="pd-lead"><?php echo esc_html( get_the_excerpt() ); ?></p></div>
        <?php endif; ?>
    </div>
</section>
<section class="pd-section">
    <div class="pd-narrow pd-page-content">
        <?php the_content(); ?>
    </div>
</section>
<?php endwhile; ?>
<?php get_footer(); ?>
