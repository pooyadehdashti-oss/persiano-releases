<?php
/**
 * WooCommerce wrapper.
 *
 * @package Persiano_Dish
 */
get_header();

$is_catalog = function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() );
if ( $is_catalog ) {
    add_filter( 'woocommerce_show_page_title', '__return_false' );
    $title       = is_shop() ? __( 'Order Online', 'persiano-dish' ) : woocommerce_page_title( false );
    $description = is_product_taxonomy() ? term_description() : __( 'Browse prepared meals and pantry products currently available from Persiano Dish.', 'persiano-dish' );
    ?>
    <section class="pd-page-hero pd-page-hero--split pd-shop-hero">
        <div class="pd-shell pd-page-hero-grid">
            <div><div class="pd-kicker"><?php esc_html_e( 'Persiano Dish shop', 'persiano-dish' ); ?></div><h1><?php echo esc_html( $title ); ?></h1></div>
            <div class="pd-page-hero-aside">
                <?php if ( $description ) : ?><div class="pd-lead"><?php echo wp_kses_post( $description ); ?></div><?php endif; ?>
                <div class="pd-inline-notes"><span><?php esc_html_e( 'Secure checkout', 'persiano-dish' ); ?></span><span><?php esc_html_e( 'Fulfilment shown at checkout', 'persiano-dish' ); ?></span></div>
            </div>
        </div>
    </section>
    <?php
}
?>
<section class="pd-section<?php echo $is_catalog ? ' pd-section--cream' : ''; ?>">
    <div class="pd-shell">
        <?php woocommerce_content(); ?>
    </div>
</section>
<?php get_footer(); ?>
