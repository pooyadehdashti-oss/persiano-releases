<?php
/**
 * Template Name: Catering
 *
 * @package Persiano_Dish
 */
get_header();
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Catering & private gatherings', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'Food made around your gathering.', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-page-hero-aside">
            <p class="pd-lead"><?php esc_html_e( 'From family dinners to celebrations and private events, Persiano Dish prepares thoughtful Persian food around the size and style of your gathering.', 'persiano-dish' ); ?></p>
            <a class="pd-btn" href="#catering-inquiry"><?php esc_html_e( 'Start an Inquiry', 'persiano-dish' ); ?></a>
        </div>
    </div>
</section>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top">
            <div><div class="pd-kicker"><?php esc_html_e( 'Made for the occasion', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'A more personal way to cater.', 'persiano-dish' ); ?></h2></div>
            <p class="pd-lead"><?php esc_html_e( 'Rather than forcing every gathering into one fixed package, we start with what you are planning and build from there.', 'persiano-dish' ); ?></p>
        </div>
        <div class="pd-service-grid">
            <article class="pd-service-card"><span>01</span><h3><?php esc_html_e( 'Private gatherings', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Food for birthdays, family dinners and celebrations where you want a generous Persian table without cooking everything yourself.', 'persiano-dish' ); ?></p></article>
            <article class="pd-service-card"><span>02</span><h3><?php esc_html_e( 'Party orders', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Larger quantities of selected dishes, appetisers and sides for hosts who are arranging the rest of the event themselves.', 'persiano-dish' ); ?></p></article>
            <article class="pd-service-card"><span>03</span><h3><?php esc_html_e( 'Custom menus', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'A menu shaped around your guest count, occasion and food preferences, subject to availability and kitchen capacity.', 'persiano-dish' ); ?></p></article>
        </div>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell pd-process-layout">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'How it works', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'Tell us about the table you are planning.', 'persiano-dish' ); ?></h2>
            <p class="pd-lead"><?php esc_html_e( 'The more we know at the beginning, the easier it is to suggest a realistic menu and confirm availability.', 'persiano-dish' ); ?></p>
        </div>
        <div class="pd-process-list">
            <article><span>1</span><div><h3><?php esc_html_e( 'Share the basics', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Date, guest count, location and the type of gathering.', 'persiano-dish' ); ?></p></div></article>
            <article><span>2</span><div><h3><?php esc_html_e( 'Build the menu', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'We discuss dishes, quantities and any important food preferences.', 'persiano-dish' ); ?></p></div></article>
            <article><span>3</span><div><h3><?php esc_html_e( 'Confirm the order', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Once the details and pricing are agreed, the catering order is confirmed.', 'persiano-dish' ); ?></p></div></article>
        </div>
    </div>
</section>

<section id="catering-inquiry" class="pd-section pd-section--dark">
    <div class="pd-shell pd-inquiry-layout">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Catering inquiry', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'Let’s start with the details.', 'persiano-dish' ); ?></h2>
            <p class="pd-lead"><?php esc_html_e( 'Use the form to tell us what you are planning. This is an inquiry, not a confirmed booking, until availability and details are agreed.', 'persiano-dish' ); ?></p>
        </div>
        <div class="pd-form-panel">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
                    <?php the_content(); ?>
                <?php else : ?>
                    <div class="pd-form-empty"><h3><?php esc_html_e( 'Add your catering inquiry form here.', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Edit this Catering page and add your WPForms form block or shortcode. The theme will style it automatically.', 'persiano-dish' ); ?></p><a class="pd-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact Persiano Dish', 'persiano-dish' ); ?></a></div>
                <?php endif; ?>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php get_footer(); ?>
