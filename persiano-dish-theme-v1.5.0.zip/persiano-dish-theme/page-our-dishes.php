<?php
/**
 * Template Name: Our Dishes
 *
 * Full Persiano prepared-food catalogue with filters and advance-order discovery.
 *
 * @package Persiano_Dish
 */
get_header();

$search       = isset( $_GET['dish_search'] ) ? sanitize_text_field( wp_unslash( $_GET['dish_search'] ) ) : '';
$course       = isset( $_GET['course'] ) ? sanitize_key( wp_unslash( $_GET['course'] ) ) : '';
$dietary      = isset( $_GET['dietary'] ) ? sanitize_key( wp_unslash( $_GET['dietary'] ) ) : '';
$availability = isset( $_GET['availability'] ) ? sanitize_key( wp_unslash( $_GET['availability'] ) ) : '';

$filters = array(
    'search'       => $search,
    'course'       => $course,
    'dietary'      => $dietary,
    'availability' => $availability,
);

$products         = persiano_dish_get_all_dishes( $filters );
$course_options   = persiano_dish_get_course_options();
$dietary_options  = persiano_dish_get_filterable_dietary_options();
$has_filters      = $search || $course || $dietary || $availability;
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'The Persiano collection', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'Our Dishes', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-page-hero-aside">
            <p class="pd-lead"><?php esc_html_e( 'Explore the full Persiano Dish collection — what is cooking now, familiar favourites, and dishes available to request in advance.', 'persiano-dish' ); ?></p>
            <div class="pd-inline-notes">
                <span><?php esc_html_e( 'Full catalogue', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Advance ordering', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Dietary filters', 'persiano-dish' ); ?></span>
            </div>
        </div>
    </div>
</section>

<?php while ( have_posts() ) : the_post(); ?>
    <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
        <section class="pd-section pd-section--compact">
            <div class="pd-shell">
                <div class="pd-rich-intro"><?php the_content(); ?></div>
            </div>
        </section>
    <?php endif; ?>
<?php endwhile; ?>

<section class="pd-section pd-section--cream pd-catalogue-section">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Browse everything', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'Find something for your table.', 'persiano-dish' ); ?></h2>
            </div>
            <p class="pd-lead"><?php esc_html_e( 'Items marked Advance Order are not part of the current batch, but can be requested for a future date when advance ordering is enabled.', 'persiano-dish' ); ?></p>
        </div>

        <form class="pd-dish-filters" method="get" action="<?php echo esc_url( persiano_dish_get_page_url( 'our-dishes' ) ); ?>">
            <label class="pd-filter-search">
                <span><?php esc_html_e( 'Search dishes', 'persiano-dish' ); ?></span>
                <input type="search" name="dish_search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'e.g. Tahchin, eggplant, chicken', 'persiano-dish' ); ?>">
            </label>

            <label>
                <span><?php esc_html_e( 'Course', 'persiano-dish' ); ?></span>
                <select name="course">
                    <option value=""><?php esc_html_e( 'All courses', 'persiano-dish' ); ?></option>
                    <?php foreach ( $course_options as $key => $label ) : ?>
                        <?php if ( '' === $key ) { continue; } ?>
                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $course, $key ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                <span><?php esc_html_e( 'Dietary', 'persiano-dish' ); ?></span>
                <select name="dietary">
                    <option value=""><?php esc_html_e( 'All dietary profiles', 'persiano-dish' ); ?></option>
                    <?php foreach ( $dietary_options as $key => $label ) : ?>
                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $dietary, $key ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                <span><?php esc_html_e( 'Availability', 'persiano-dish' ); ?></span>
                <select name="availability">
                    <option value=""><?php esc_html_e( 'Any availability', 'persiano-dish' ); ?></option>
                    <option value="available_now" <?php selected( $availability, 'available_now' ); ?>><?php esc_html_e( 'Available now', 'persiano-dish' ); ?></option>
                    <option value="advance_order" <?php selected( $availability, 'advance_order' ); ?>><?php esc_html_e( 'Advance order available', 'persiano-dish' ); ?></option>
                </select>
            </label>

            <div class="pd-filter-actions">
                <button class="pd-btn" type="submit"><?php esc_html_e( 'Apply filters', 'persiano-dish' ); ?></button>
                <?php if ( $has_filters ) : ?>
                    <a class="pd-filter-reset" href="<?php echo esc_url( persiano_dish_get_page_url( 'our-dishes' ) ); ?>"><?php esc_html_e( 'Clear', 'persiano-dish' ); ?></a>
                <?php endif; ?>
            </div>
        </form>

        <div class="pd-catalogue-summary">
            <span><?php echo esc_html( sprintf( _n( '%d dish', '%d dishes', count( $products ), 'persiano-dish' ), count( $products ) ) ); ?></span>
            <span><?php esc_html_e( 'Prices shown include applicable tax.', 'persiano-dish' ); ?></span>
        </div>

        <?php if ( $products ) : ?>
            <div class="pd-product-grid">
                <?php foreach ( $products as $product ) : ?>
                    <?php
                    $details = function_exists( 'persiano_hub_get_product_details' ) ? persiano_hub_get_product_details( $product->get_id() ) : array();
                    $badge   = '';
                    if ( ! empty( $details['course'] ) && isset( $course_options[ $details['course'] ] ) ) {
                        $badge = $course_options[ $details['course'] ];
                    }
                    get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => $badge ) );
                    ?>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="pd-empty-state">
                <div class="pd-empty-state-mark">P</div>
                <div>
                    <h3><?php esc_html_e( 'No dishes match those filters.', 'persiano-dish' ); ?></h3>
                    <p><?php esc_html_e( 'Try clearing one of the filters to see more of the Persiano collection.', 'persiano-dish' ); ?></p>
                    <a class="pd-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'our-dishes' ) ); ?>"><?php esc_html_e( 'View all dishes', 'persiano-dish' ); ?></a>
                </div>
            </div>
        <?php endif; ?>

        <p class="pd-dietary-disclaimer"><?php esc_html_e( 'Dietary labels describe the standard recipe. Persiano Dish is a shared kitchen environment, so please contact us about allergies or serious dietary restrictions before ordering.', 'persiano-dish' ); ?></p>
    </div>
</section>

<section class="pd-callout-band">
    <div class="pd-shell pd-callout-band-inner">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Ready sooner?', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'See what is cooking this week.', 'persiano-dish' ); ?></h2>
        </div>
        <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'this-week', '/shop/' ) ); ?>"><?php esc_html_e( 'Browse This Week', 'persiano-dish' ); ?></a>
    </div>
</section>
<?php get_footer(); ?>
