<?php
/**
 * Template Name: This Week
 *
 * Prepared-meal ordering page.
 *
 * @package Persiano_Dish
 */
get_header();
$query = persiano_dish_get_category_products( 'this-week', 24 );
?>
<section class="pd-page-hero pd-page-hero--split">
    <div class="pd-shell pd-page-hero-grid">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Prepared meals', 'persiano-dish' ); ?></div>
            <h1><?php esc_html_e( 'This Week at Persiano', 'persiano-dish' ); ?></h1>
        </div>
        <div class="pd-page-hero-aside">
            <p class="pd-lead"><?php esc_html_e( 'A changing small-batch menu prepared in limited quantities. Choose what is cooking, place your order, and we will take care of the rest.', 'persiano-dish' ); ?></p>
            <div class="pd-inline-notes">
                <span><?php esc_html_e( 'Pre-order', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Limited batches', 'persiano-dish' ); ?></span>
                <span><?php esc_html_e( 'Local pickup & delivery', 'persiano-dish' ); ?></span>
            </div>
        </div>
    </div>
</section>

<?php while ( have_posts() ) : the_post(); ?>
    <?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
        <section class="pd-section pd-section--compact">
            <div class="pd-shell">
                <div class="pd-rich-intro"><?php the_content(); ?></div>
            </div>
        </section>
    <?php endif; ?>
<?php endwhile; ?>

<section class="pd-section pd-section--cream">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Available to order', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'What’s cooking', 'persiano-dish' ); ?></h2>
            </div>
            <p class="pd-lead"><?php esc_html_e( 'Availability changes as each batch fills. Check each dish for its available date and order deadline.', 'persiano-dish' ); ?></p>
        </div>

        <?php if ( $query->have_posts() ) : ?>
            <div class="pd-product-grid">
                <?php while ( $query->have_posts() ) : $query->the_post(); global $product; ?>
                    <?php get_template_part( 'template-parts/product-card', null, array( 'product' => $product, 'badge' => __( 'Prepared Meal', 'persiano-dish' ) ) ); ?>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <div class="pd-empty-state">
                <div class="pd-empty-state-mark">P</div>
                <div>
                    <h3><?php esc_html_e( 'The next menu is being prepared.', 'persiano-dish' ); ?></h3>
                    <p><?php esc_html_e( 'New prepared meals will appear here as soon as the next Persiano menu is released.', 'persiano-dish' ); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="pd-section">
    <div class="pd-shell">
        <div class="pd-section-head pd-section-head--top">
            <div>
                <div class="pd-kicker"><?php esc_html_e( 'Ordering', 'persiano-dish' ); ?></div>
                <h2><?php esc_html_e( 'From menu to table, made simple.', 'persiano-dish' ); ?></h2>
            </div>
        </div>
        <div class="pd-step-grid">
            <article class="pd-step-card"><span>01</span><h3><?php esc_html_e( 'Choose your dishes', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Browse the current menu and select the quantity you would like.', 'persiano-dish' ); ?></p></article>
            <article class="pd-step-card"><span>02</span><h3><?php esc_html_e( 'Choose pickup or delivery', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Select from the available pickup and local delivery options at checkout.', 'persiano-dish' ); ?></p></article>
            <article class="pd-step-card"><span>03</span><h3><?php esc_html_e( 'Place your order', 'persiano-dish' ); ?></h3><p><?php esc_html_e( 'Complete checkout securely and receive your order confirmation.', 'persiano-dish' ); ?></p></article>
        </div>
    </div>
</section>

<section class="pd-section pd-section--compact">
    <div class="pd-shell pd-catalogue-link-card">
        <div>
            <div class="pd-kicker"><?php esc_html_e( 'Not on this week’s menu?', 'persiano-dish' ); ?></div>
            <h2><?php esc_html_e( 'Explore the full Persiano collection.', 'persiano-dish' ); ?></h2>
            <p><?php esc_html_e( 'Browse all dishes and request eligible favourites as an advance order.', 'persiano-dish' ); ?></p>
        </div>
        <a class="pd-btn" href="<?php echo esc_url( persiano_dish_get_page_url( 'our-dishes' ) ); ?>"><?php esc_html_e( 'View Our Dishes', 'persiano-dish' ); ?></a>
    </div>
</section>

<section class="pd-callout-band">
    <div class="pd-shell pd-callout-band-inner">
        <div><div class="pd-kicker"><?php esc_html_e( 'Stock your kitchen too', 'persiano-dish' ); ?></div><h2><?php esc_html_e( 'Looking for something to keep at home?', 'persiano-dish' ); ?></h2></div>
        <a class="pd-btn pd-btn--light" href="<?php echo esc_url( persiano_dish_get_page_url( 'the-pantry', '/shop/' ) ); ?>"><?php esc_html_e( 'Visit the Pantry', 'persiano-dish' ); ?></a>
    </div>
</section>
<?php get_footer(); ?>
