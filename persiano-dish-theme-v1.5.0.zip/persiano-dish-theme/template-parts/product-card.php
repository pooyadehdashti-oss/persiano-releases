<?php
/**
 * Product card.
 *
 * @package Persiano_Dish
 */
$product = isset( $args['product'] ) ? $args['product'] : null;
$badge   = isset( $args['badge'] ) ? $args['badge'] : '';
if ( ! $product ) {
    return;
}

$stock_quantity = $product->managing_stock() ? $product->get_stock_quantity() : null;
$is_low_stock   = $product->is_in_stock() && null !== $stock_quantity && $stock_quantity > 0 && $stock_quantity <= 5;
$details        = function_exists( 'persiano_hub_get_product_details' ) ? persiano_hub_get_product_details( $product->get_id() ) : array();
$is_available   = $product->is_in_stock() && $product->is_purchasable();
$can_advance    = ! empty( $details['allow_advance_order'] );
?>
<article class="pd-product-card">
    <a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" class="pd-product-image" aria-label="<?php echo esc_attr( $product->get_name() ); ?>">
        <?php echo $product->get_image( 'woocommerce_thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </a>
    <div class="pd-product-body">
        <div class="pd-product-meta">
            <?php if ( $badge ) : ?><span class="pd-badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
            <?php if ( ! $is_available && $can_advance ) : ?>
                <span class="pd-badge pd-badge--green"><?php esc_html_e( 'Advance Order', 'persiano-dish' ); ?></span>
            <?php elseif ( ! $is_available ) : ?>
                <span class="pd-badge pd-badge--gold"><?php esc_html_e( 'Currently Unavailable', 'persiano-dish' ); ?></span>
            <?php elseif ( $is_low_stock ) : ?>
                <span class="pd-badge pd-badge--gold"><?php echo esc_html( sprintf( _n( 'Only %d left', 'Only %d left', $stock_quantity, 'persiano-dish' ), $stock_quantity ) ); ?></span>
            <?php endif; ?>
        </div>
        <h3><a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>
        <?php do_action( 'persiano_dish_product_card_details', $product ); ?>
        <div class="pd-product-card-bottom">
            <div class="pd-product-price"><?php echo wp_kses_post( $product->get_price_html() ); ?><small><?php esc_html_e( 'Tax included', 'persiano-dish' ); ?></small></div>
            <a class="pd-product-link" href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>"><?php echo esc_html( ( ! $is_available && $can_advance ) ? __( 'View & Advance Order', 'persiano-dish' ) : __( 'View & Order', 'persiano-dish' ) ); ?> <span aria-hidden="true">→</span></a>
        </div>
    </div>
</article>
