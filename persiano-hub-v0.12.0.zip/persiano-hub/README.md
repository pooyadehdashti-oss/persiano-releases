# Persiano Hub 0.9.0

## 0.9.0 — Publishing cleanup and management redesign
- Added **Persiano Hub → Website Content** so WooCommerce product destinations and Persiano Update destinations can be found and managed from one screen.
- Reworked the campaign list with a clear Website destination column, selected-channel chips, and publishing status.
- Moved Publishing Status into a full-width panel with one card per channel and clear “selected for next publish” indicators.
- Fixed the immediate-publish architecture so manual publishing is dispatched only after the current form and channel checkboxes are saved.
- Manual dispatches now use an exact saved channel-selection snapshot; unchecked channels are excluded.
- Removed the old immediate transition dispatch that could race with saved checkbox changes and contribute to duplicate Telegram sends.
- Preserved previous channel history and published links even after a destination is unchecked.
- Simplified action buttons to Save Draft / Save Changes / Publish Selected Channels / Retry Failed Channels.
- Added safer browser-side submit handling so an old publish action cannot remain behind when the user later clicks Save.
- Clarified Website behavior for WooCommerce products versus Persiano Updates.
- Collapsed platform-specific captions into an optional section to reduce editor clutter.


Version 0.6.0 introduces the first **Persiano Publishing Hub** while preserving the existing commerce, fulfilment, advance-order, email-branding, and mailing-list features.

## Publishing Hub
A new **Persiano Hub** admin menu provides:

- **Overview** dashboard with campaign counts, recent content, and channel connection status.
- **Publishing** content type for creating one campaign and choosing its destinations.
- **Connections** page for Telegram, Instagram, and Google Business Profile credentials.
- Standard WordPress draft/publish/scheduling workflow.
- Per-channel delivery status, error logs, retry, and intentional republishing.

### Content types
- Weekly Menu
- Individual Dish
- Pantry Product
- Event
- Catering
- Special Offer
- General Update

### Destinations
- Website
- Instagram
- Telegram
- Google Business

The main WordPress editor is the shared long-form content. Each social platform can have its own optional caption. A featured image is the default website/social image, while a separate video can be selected for Instagram and Telegram and a separate image can be selected for Google Business.

## Website publishing
Selecting **Website** creates or updates a normal WordPress post in the **Persiano Updates** category. Persiano Hub also creates an `/updates/` page containing the `[persiano_updates]` feed shortcode.

## Telegram
Configure a Bot API token and target chat/channel under **Persiano Hub → Connections**. The bot must have permission to post to the selected channel. Persiano Hub can send:
- Video + caption
- Photo + caption
- Text-only posts

## Instagram
Configure the Instagram User ID and a Meta access token with content-publishing permissions. Persiano Hub publishes:
- Featured-image feed posts
- Selected videos as Reels

The Graph API version is optional/configurable so the integration can follow the version used by the connected Meta app.

## Google Business Profile
Configure Google OAuth client credentials, authorize the account, then enter the Business Account ID and Location ID. Persiano Hub publishes standard updates and event posts, with an appropriate call-to-action URL and optional image.

## Scheduling
Use WordPress's normal **Publish immediately / Schedule** controls. When WordPress publishes the campaign, Persiano Hub dispatches the selected channels. WP-Cron timing depends on the site receiving traffic unless a real server cron is configured.

## Existing Persiano features retained
- WooCommerce product fields and This Week/Pantry placement
- Pickup, local delivery, and Pantry shipping rules
- Square and invoice/manual payment compatibility
- Advance orders with future requested dates and admin confirmation workflow
- Persiano-branded WooCommerce emails
- Mailing-list signup, consent tracking, unsubscribe, and CSV export



## 0.7.6
- Fixed a fatal error on brand-new Publishing campaigns where missing WordPress post meta was cast from an empty string into a one-item array.
- Hardened publishing status and activity-log rendering against malformed or legacy meta values.
- Keeps the classic campaign editor introduced in 0.7.5.


## 0.7.5
- Switched Facebook Login for Business OAuth to the Configuration ID flow.
- Removed raw Instagram/Page permission scopes from the OAuth URL; Meta now applies permissions from the selected Business Login configuration.
- Made the Facebook Login Configuration ID a required visible connection field.

## 0.7.3
- Fixed Meta Facebook Login OAuth scope for Instagram publishing: `instagram_content_publish`.

## 0.10.0
- Added full dish catalogue metadata: course, dietary profile and available alterations.
- Added tax-inclusive WooCommerce setup and prepared-meal tax defaults.
- New dish drafts created from Publishing no longer appear in This Week automatically.

## 0.11.0
- Adds Persiano direct updates through a GitHub Releases repository.
- Supports public or private repositories; private release assets are downloaded with a stored read-only token.
- Adds Persiano Hub → Updates for configuration, status, and manual update checks.


## 0.12.0 — Ingredients, Recipes & Pricing

- Adds Persiano Hub → Pricing & Costing dashboard.
- Adds Ingredients database with package cost, unit conversions, waste/trim, suppliers and cost history.
- Adds Recipes & Pricing with repeatable ingredient quantities, batch yield, packaging, labour, overhead and target-cost pricing.
- Links recipes directly to WooCommerce products.
- Calculates batch cost, cost per serving, suggested tax-inclusive displayed price and estimated gross margin.
- Adds an explicit “Apply suggested price to product” action.
- Leaves the older Persiano Pricing plugin/data untouched when detected.
