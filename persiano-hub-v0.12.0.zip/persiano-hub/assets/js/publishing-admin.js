(function ($) {
  'use strict';

  var publishSubmissionStarted = false;

  function updateEventFields() {
    var type = $('#persiano_pub_type').val();
    $('.ph-event-fields').toggleClass('is-visible', type === 'event');
    updateWebsiteBehaviour();
  }

  function updateWebsiteBehaviour() {
    var type = $('#persiano_pub_type').val();
    var productId = $('#persiano_pub_product_id').val();
    var help = $('#ph-product-link-help');
    var note = $('#ph-website-behaviour-note');
    var text = '';
    var productHelp = '';

    if (type === 'dish' || type === 'pantry') {
      if (productId && productId !== '0') {
        text = 'Website uses the selected WooCommerce product. Publishing this campaign does not create a duplicate website post.';
        productHelp = 'This existing WooCommerce product remains the website source of truth for price, stock and product details.';
      } else {
        text = 'Publishing to Website creates one WooCommerce product draft and links it to this campaign. Finish price, stock and operational details under Products before making it live.';
        productHelp = 'Leave this empty to create a new linked WooCommerce product draft the first time Website is published.';
      }
    } else if (type === 'weekly_menu') {
      text = 'Website creates or updates one Weekly Menu post in Persiano Updates. Menu dishes remain separate WooCommerce products.';
      productHelp = 'Optional: select one product only when you want the default call-to-action to lead to it.';
    } else {
      text = 'Website creates or updates one Persiano Update for this campaign. Republishing updates the same website item instead of creating a duplicate.';
      productHelp = 'Optional: link a product when the campaign call-to-action should lead to a WooCommerce item.';
    }

    help.text(productHelp);
    note.text(text);
  }

  function refreshChannelSelectionUI() {
    $('.ph-channel-checks label').each(function () {
      var label = $(this);
      var checkbox = label.find('input[type="checkbox"]');
      label.toggleClass('is-selected', checkbox.is(':checked'));
    });

    var selected = $('.ph-channel-checks input[type="checkbox"]:checked').length;
    $('.ph-channel-selection-count').remove();
    $('.ph-channel-checks').after(
      $('<div>', {
        'class': 'ph-channel-selection-count',
        text: selected ? selected + ' destination' + (selected === 1 ? '' : 's') + ' selected for the next publish.' : 'No destinations selected. Saving is still safe; publishing will send nothing.'
      })
    );
  }

  function openMediaFrame(options, onSelect) {
    if (typeof window.wp === 'undefined' || !wp.media) {
      window.alert('The WordPress Media Library did not load. Please refresh this page and try again.');
      return;
    }

    var frame = wp.media({
      title: options.title || 'Choose media',
      button: { text: options.buttonText || 'Use this media' },
      library: options.mediaType ? { type: options.mediaType } : undefined,
      multiple: false
    });

    frame.on('select', function () {
      var selection = frame.state().get('selection');
      if (!selection || !selection.first()) {
        return;
      }
      onSelect(selection.first().toJSON());
    });

    frame.open();
  }

  function insertAtCursor(textarea, text) {
    var el = textarea.get(0);
    if (!el) return;
    var start = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
    var end = typeof el.selectionEnd === 'number' ? el.selectionEnd : el.value.length;
    var before = el.value.substring(0, start);
    var after = el.value.substring(end);
    el.value = before + text + after;
    var cursor = start + text.length;
    el.focus();
    if (el.setSelectionRange) el.setSelectionRange(cursor, cursor);
  }

  function setPublishAction(value) {
    var form = $('#post');
    var hidden = form.find('input[name="persiano_hub_publish_action"]');
    if (!hidden.length) {
      hidden = $('<input>', { type: 'hidden', name: 'persiano_hub_publish_action' }).appendTo(form);
    }
    hidden.val(value || '');
  }

  $(document).on('change', '#persiano_pub_type, #persiano_pub_product_id', updateEventFields);
  $(document).on('change', '.ph-channel-checks input[type="checkbox"]', refreshChannelSelectionUI);
  updateEventFields();
  refreshChannelSelectionUI();

  // Every submit button explicitly sets or clears the publishing action. This
  // prevents a previous failed/blocked publish click from leaving a hidden action
  // behind and accidentally sending channels when the user later clicks Save.
  $(document).on('click', '#post button[type="submit"], #post input[type="submit"]', function (event) {
    var button = $(this);
    var action = button.attr('data-ph-publish-action') || '';
    setPublishAction(action);

    if (action) {
      if (publishSubmissionStarted) {
        event.preventDefault();
        return false;
      }
      publishSubmissionStarted = true;
      button.addClass('is-publishing').attr('aria-busy', 'true');
    }
  });

  $(document).on('click', '.ph-select-media', function (event) {
    event.preventDefault();
    var button = $(this);
    var field = button.closest('.ph-media-field');
    var mediaType = button.data('media-type') || 'image';

    openMediaFrame({
      title: mediaType === 'video' ? 'Choose video' : 'Choose image',
      buttonText: 'Use this media',
      mediaType: mediaType
    }, function (attachment) {
      field.find('.ph-media-id').val(attachment.id).trigger('change');
      if (mediaType === 'image') {
        var url = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
        field.find('.ph-media-preview').html('<img src="' + url + '" alt="">');
      } else {
        field.find('.ph-media-preview').text(attachment.filename || attachment.url);
      }
    });
  });

  $(document).on('click', '.ph-insert-content-media', function (event) {
    event.preventDefault();
    openMediaFrame({
      title: 'Add media to shared content',
      buttonText: 'Insert media'
    }, function (attachment) {
      var markup;
      if (attachment.type === 'image') {
        markup = '<img src="' + attachment.url + '" alt="">';
      } else {
        markup = attachment.url;
      }
      insertAtCursor($('#ph_shared_content'), '\n' + markup + '\n');
    });
  });

  $(document).on('click', '.ph-clear-media', function (event) {
    event.preventDefault();
    var field = $(this).closest('.ph-media-field');
    field.find('.ph-media-id').val('').trigger('change');
    field.find('.ph-media-preview').text('No media selected');
  });
})(jQuery);
