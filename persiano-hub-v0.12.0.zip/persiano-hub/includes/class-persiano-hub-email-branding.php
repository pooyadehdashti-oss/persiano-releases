<?php
/**
 * Persiano-branded WooCommerce order emails and thank-you messaging.
 *
 * @package Persiano_Hub
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Persiano_Hub_Email_Branding {
    public static function init() {
        add_filter( 'woocommerce_email_styles', array( __CLASS__, 'email_styles' ), 30, 2 );
        add_filter( 'woocommerce_email_header_image', array( __CLASS__, 'header_image' ) );
        add_filter( 'woocommerce_email_footer_text', array( __CLASS__, 'footer_text' ) );
        add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_email_template' ), 20, 3 );

        add_filter( 'woocommerce_email_subject_customer_on_hold_order', array( __CLASS__, 'subject_on_hold' ), 20, 2 );
        add_filter( 'woocommerce_email_heading_customer_on_hold_order', array( __CLASS__, 'heading_on_hold' ), 20, 2 );
        add_filter( 'woocommerce_email_subject_customer_processing_order', array( __CLASS__, 'subject_processing' ), 20, 2 );
        add_filter( 'woocommerce_email_heading_customer_processing_order', array( __CLASS__, 'heading_processing' ), 20, 2 );
        add_filter( 'woocommerce_email_subject_customer_completed_order', array( __CLASS__, 'subject_completed' ), 20, 2 );
        add_filter( 'woocommerce_email_heading_customer_completed_order', array( __CLASS__, 'heading_completed' ), 20, 2 );

        add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'render_customer_next_steps' ), 35, 4 );
        add_action( 'woocommerce_thankyou', array( __CLASS__, 'render_thankyou_next_steps' ), 30 );
    }

    /**
     * Use a Persiano-specific on-hold template so advance-order requests do not
     * inherit WooCommerce's generic "waiting for payment" wording.
     */
    public static function locate_email_template( $template, $template_name, $template_path ) {
        $overrides = array(
            'emails/customer-on-hold-order.php',
            'emails/plain/customer-on-hold-order.php',
        );

        if ( ! in_array( $template_name, $overrides, true ) ) {
            return $template;
        }

        $candidate = PERSIANO_HUB_PATH . 'templates/' . $template_name;
        return file_exists( $candidate ) ? $candidate : $template;
    }

    public static function email_styles( $css, $email ) {
        $css .= '\n'
            . 'body{background:#f8f3e9!important;color:#2f231d!important;}'
            . '#wrapper{background:#f8f3e9!important;padding:28px 0!important;}'
            . '#template_container{border:0!important;border-radius:22px!important;overflow:hidden!important;box-shadow:0 18px 50px rgba(47,35,29,.08)!important;}'
            . '#template_header{background:#8e2435!important;border-radius:0!important;}'
            . '#template_header h1{color:#fffaf2!important;font-family:Georgia,serif!important;font-weight:600!important;letter-spacing:-.02em!important;}'
            . '#template_body{background:#fffaf2!important;}'
            . '#body_content_inner{color:#5f554c!important;}'
            . 'h1,h2,h3{font-family:Georgia,serif!important;color:#2f231d!important;}'
            . 'a{color:#8e2435!important;}'
            . '.button,a.button{background:#8e2435!important;border-color:#8e2435!important;color:#fffaf2!important;border-radius:999px!important;}'
            . '#template_footer{background:#2f231d!important;}'
            . '#credit{color:rgba(255,250,242,.72)!important;}'
            . '#credit a{color:#d79a2d!important;}'
            . 'table.td,th.td,td.td{border-color:#e5dfd5!important;}'
            . 'td#header_wrapper{padding:28px 36px!important;}'
            . 'td#body_content{padding:0!important;}'
            . 'td#body_content>table>tbody>tr>td{padding:34px 38px!important;}'
            . '@media only screen and (max-width:600px){td#body_content>table>tbody>tr>td{padding:24px 20px!important;}td#header_wrapper{padding:24px 20px!important;}}';
        return $css;
    }

    public static function header_image( $url ) {
        $logo_id = absint( get_theme_mod( 'persiano_header_logo', 0 ) );
        if ( ! $logo_id ) {
            $logo_id = absint( get_theme_mod( 'custom_logo', 0 ) );
        }
        if ( $logo_id ) {
            $image = wp_get_attachment_image_url( $logo_id, 'medium' );
            if ( $image ) {
                return $image;
            }
        }
        return $url;
    }

    public static function footer_text( $text ) {
        $email = sanitize_email( get_theme_mod( 'persiano_contact_email', 'info@persianodish.com' ) );
        if ( ! $email ) {
            $email = 'info@persianodish.com';
        }
        return sprintf(
            '%1$s<br>%2$s <a href="mailto:%3$s">%3$s</a>',
            esc_html__( 'Persiano Dish · Homemade Persian food in North & West Vancouver', 'persiano-hub' ),
            esc_html__( 'Questions about your order?', 'persiano-hub' ),
            esc_attr( $email )
        );
    }

    public static function subject_on_hold( $subject, $order ) {
        if ( self::is_unconfirmed_advance_order( $order ) ) {
            return self::subject_with_number( __( 'Your Persiano Dish advance order request #%s was received', 'persiano-hub' ), $order );
        }
        return self::subject_with_number( __( 'We received your Persiano Dish order #%s', 'persiano-hub' ), $order );
    }

    public static function heading_on_hold( $heading, $order ) {
        if ( self::is_unconfirmed_advance_order( $order ) ) {
            return __( 'Your advance order is pending confirmation', 'persiano-hub' );
        }
        return __( 'Your order is in', 'persiano-hub' );
    }

    public static function subject_processing( $subject, $order ) {
        return self::subject_with_number( __( 'Your Persiano Dish order #%s is confirmed', 'persiano-hub' ), $order );
    }

    public static function heading_processing( $heading, $order ) {
        return __( 'Your order is confirmed', 'persiano-hub' );
    }

    public static function subject_completed( $subject, $order ) {
        return self::subject_with_number( __( 'Your Persiano Dish order #%s is complete', 'persiano-hub' ), $order );
    }

    public static function heading_completed( $heading, $order ) {
        return __( 'Thank you — your order is complete', 'persiano-hub' );
    }

    public static function render_customer_next_steps( $order, $sent_to_admin, $plain_text, $email ) {
        if ( $sent_to_admin || ! $order instanceof WC_Order ) {
            return;
        }

        $title = __( 'What happens next', 'persiano-hub' );
        $lines = self::next_steps_for_order( $order );
        if ( empty( $lines ) ) {
            return;
        }

        if ( $plain_text ) {
            echo "\n" . $title . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            foreach ( $lines as $line ) {
                echo '• ' . wp_strip_all_tags( $line ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
            return;
        }

        echo '<section style="margin:26px 0 18px;padding:22px 24px;border-radius:16px;background:#f8f3e9;border-left:4px solid #8e2435;">';
        echo '<h2 style="margin:0 0 10px;color:#2f231d;font-family:Georgia,serif;">' . esc_html( $title ) . '</h2><ul style="margin:0;padding-left:20px;color:#5f554c;">';
        foreach ( $lines as $line ) {
            echo '<li style="margin:6px 0;">' . esc_html( $line ) . '</li>';
        }
        echo '</ul></section>';
    }

    public static function render_thankyou_next_steps( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }
        $lines = self::next_steps_for_order( $order );
        if ( empty( $lines ) ) {
            return;
        }
        $eyebrow = self::is_unconfirmed_advance_order( $order )
            ? __( 'Request received', 'persiano-hub' )
            : __( 'Order received', 'persiano-hub' );
        echo '<section class="ph-thankyou-next"><span class="ph-thankyou-next-eyebrow">' . esc_html( $eyebrow ) . '</span><h2>' . esc_html__( 'What happens next', 'persiano-hub' ) . '</h2><ul>';
        foreach ( $lines as $line ) {
            echo '<li>' . esc_html( $line ) . '</li>';
        }
        echo '</ul></section>';
    }

    private static function next_steps_for_order( $order ) {
        $lines = array();

        if ( self::is_unconfirmed_advance_order( $order ) ) {
            $lines[] = __( 'Your advance-order request is pending confirmation from Persiano Dish.', 'persiano-hub' );
            $lines[] = __( 'We will review the requested date and availability before confirming the order.', 'persiano-hub' );
            $lines[] = __( 'No online payment is required until the advance order is confirmed.', 'persiano-hub' );
        } else {
            $payment_method = $order->get_payment_method();
            if ( $order->has_status( 'on-hold' ) || 'invoice' === $payment_method || false !== stripos( $order->get_payment_method_title(), 'invoice' ) ) {
                $lines[] = __( 'Your order has been received and is reserved while payment or cash arrangements are completed.', 'persiano-hub' );
            } elseif ( $order->is_paid() ) {
                $lines[] = __( 'Your payment has been received.', 'persiano-hub' );
            }
        }

        $method_title = '';
        foreach ( $order->get_shipping_methods() as $shipping_item ) {
            $method_title = $shipping_item->get_name();
            break;
        }
        if ( $method_title ) {
            $lines[] = sprintf( __( 'Your selected fulfilment method is: %s.', 'persiano-hub' ), $method_title );
        }

        if ( self::is_unconfirmed_advance_order( $order ) ) {
            $lines[] = __( 'Once approved, you will receive an order confirmation with payment instructions or a secure payment link.', 'persiano-hub' );
        } elseif ( self::order_has_advance_items( $order ) ) {
            $lines[] = __( 'Your requested advance-order date is recorded in the order details below.', 'persiano-hub' );
        }

        $lines[] = __( 'You will receive another email when the order status changes.', 'persiano-hub' );
        return $lines;
    }

    public static function is_unconfirmed_advance_order( $order ) {
        return $order instanceof WC_Order
            && 'yes' === $order->get_meta( '_persiano_advance_order_request', true )
            && 'yes' !== $order->get_meta( '_persiano_advance_order_confirmed', true );
    }

    private static function order_has_advance_items( $order ) {
        foreach ( $order->get_items() as $item ) {
            if ( 'yes' === $item->get_meta( '_persiano_advance_order', true ) ) {
                return true;
            }
        }
        return false;
    }

    private static function subject_with_number( $template, $order ) {
        $number = $order instanceof WC_Order ? $order->get_order_number() : '';
        return sprintf( $template, $number );
    }
}
