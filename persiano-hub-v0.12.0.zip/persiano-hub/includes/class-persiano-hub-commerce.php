<?php
/**
 * Commerce helpers for Persiano Hub.
 *
 * @package Persiano_Hub
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Persiano_Hub_Commerce {
    public static function init() {
        add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'cleanup_legacy_cart_item_data' ), 5, 2 );
        add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'cart_item_data' ), 20, 2 );
        add_filter( 'woocommerce_order_item_get_formatted_meta_data', array( __CLASS__, 'cleanup_order_item_meta' ), 20, 2 );
        add_action( 'woocommerce_check_cart_items', array( __CLASS__, 'validate_cart_deadlines' ) );
        add_filter( 'woocommerce_order_button_text', array( __CLASS__, 'classic_order_button_text' ) );
        add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'save_order_item_details' ), 20, 4 );
    }


    /**
     * Remove legacy/internal product fields from the customer-facing cart when
     * Persiano Hub now owns the structured equivalent.
     */
    public static function cleanup_legacy_cart_item_data( $item_data, $cart_item ) {
        $product_id = ! empty( $cart_item['persiano_original_product_id'] ) ? absint( $cart_item['persiano_original_product_id'] ) : ( ! empty( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0 );
        $details    = $product_id && function_exists( 'persiano_hub_get_product_details' ) ? persiano_hub_get_product_details( $product_id ) : array();
        $has_size   = ! empty( $details['size'] );

        foreach ( (array) $item_data as $index => $row ) {
            $label = isset( $row['key'] ) ? $row['key'] : ( isset( $row['name'] ) ? $row['name'] : '' );
            if ( self::is_hidden_legacy_label( $label, $has_size ) ) {
                unset( $item_data[ $index ] );
            }
        }

        return array_values( $item_data );
    }

    /**
     * Keep internal bilingual/import metadata out of customer and admin order
     * summaries while retaining useful customer notes.
     */
    public static function cleanup_order_item_meta( $formatted_meta, $item ) {
        $product_id = is_object( $item ) && method_exists( $item, 'get_product_id' ) ? absint( $item->get_product_id() ) : 0;
        $details    = $product_id && function_exists( 'persiano_hub_get_product_details' ) ? persiano_hub_get_product_details( $product_id ) : array();
        $has_size   = ! empty( $details['size'] );

        foreach ( (array) $formatted_meta as $meta_id => $meta ) {
            $label = '';
            if ( is_object( $meta ) ) {
                $label = isset( $meta->display_key ) ? $meta->display_key : ( isset( $meta->key ) ? $meta->key : '' );
            }
            if ( self::is_hidden_legacy_label( $label, $has_size ) ) {
                unset( $formatted_meta[ $meta_id ] );
            }
        }

        return $formatted_meta;
    }

    public static function cart_item_data( $item_data, $cart_item ) {
        $product_id = ! empty( $cart_item['persiano_original_product_id'] ) ? absint( $cart_item['persiano_original_product_id'] ) : ( ! empty( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0 );
        if ( ! $product_id || ! function_exists( 'persiano_hub_get_product_details' ) ) {
            return $item_data;
        }

        $details = persiano_hub_get_product_details( $product_id );

        if ( empty( $cart_item['persiano_advance_order'] ) && ! empty( $details['available_date'] ) ) {
            $item_data[] = array(
                'key'   => __( 'Available', 'persiano-hub' ),
                'value' => self::format_date( $details['available_date'] ),
            );
        }

        if ( ! empty( $details['size'] ) ) {
            $item_data[] = array(
                'key'   => __( 'Size', 'persiano-hub' ),
                'value' => sanitize_text_field( $details['size'] ),
            );
        }

        $methods = self::fulfilment_methods( $details );
        if ( $methods ) {
            $item_data[] = array(
                'key'   => __( 'Available by', 'persiano-hub' ),
                'value' => $methods,
            );
        }

        return $item_data;
    }

    public static function validate_cart_deadlines() {
        if ( ! function_exists( 'WC' ) || ! WC()->cart || ! function_exists( 'persiano_hub_get_product_details' ) ) {
            return;
        }

        foreach ( WC()->cart->get_cart() as $cart_item ) {
            if ( ! empty( $cart_item['persiano_advance_order'] ) ) {
                continue;
            }
            $product_id = ! empty( $cart_item['persiano_original_product_id'] ) ? absint( $cart_item['persiano_original_product_id'] ) : ( ! empty( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0 );
            if ( ! $product_id ) {
                continue;
            }

            $details = persiano_hub_get_product_details( $product_id );
            if ( empty( $details['close_at_deadline'] ) || empty( $details['order_deadline'] ) ) {
                continue;
            }

            try {
                $deadline = new DateTimeImmutable( $details['order_deadline'], wp_timezone() );
                $now = new DateTimeImmutable( 'now', wp_timezone() );
                if ( $now >= $deadline ) {
                    $product = wc_get_product( $product_id );
                    wc_add_notice(
                        sprintf(
                            /* translators: %s: product name */
                            __( '%s can no longer be ordered because its order deadline has passed. Please remove it from your cart.', 'persiano-hub' ),
                            $product ? $product->get_name() : __( 'This item', 'persiano-hub' )
                        ),
                        'error'
                    );
                }
            } catch ( Exception $e ) {
                continue;
            }
        }
    }

    public static function classic_order_button_text( $text ) {
        return __( 'Place Order & Pay', 'persiano-hub' );
    }

    public static function save_order_item_details( $item, $cart_item_key, $values, $order ) {
        $product_id = ! empty( $values['persiano_original_product_id'] ) ? absint( $values['persiano_original_product_id'] ) : ( ! empty( $values['product_id'] ) ? absint( $values['product_id'] ) : 0 );
        if ( ! $product_id || ! function_exists( 'persiano_hub_get_product_details' ) ) {
            return;
        }

        $details = persiano_hub_get_product_details( $product_id );

        if ( empty( $values['persiano_advance_order'] ) && ! empty( $details['available_date'] ) ) {
            $item->add_meta_data( __( 'Available', 'persiano-hub' ), self::format_date( $details['available_date'] ), true );
        }
        if ( ! empty( $details['size'] ) ) {
            $item->add_meta_data( __( 'Size', 'persiano-hub' ), sanitize_text_field( $details['size'] ), true );
        }
        $methods = self::fulfilment_methods( $details );
        if ( $methods ) {
            $item->add_meta_data( __( 'Available by', 'persiano-hub' ), $methods, true );
        }
    }


    private static function is_hidden_legacy_label( $label, $has_size = false ) {
        $normalized = strtolower( trim( wp_strip_all_tags( (string) $label ) ) );
        $normalized = preg_replace( '/\s+/', ' ', $normalized );

        $hidden = array(
            'title fa',
            'fa title',
            'description fa',
            'fa description',
            'fa note',
        );

        if ( $has_size ) {
            $hidden[] = 'serving size';
        }

        return in_array( $normalized, $hidden, true );
    }

    private static function fulfilment_methods( $details ) {
        $methods = array();
        if ( ! empty( $details['pickup'] ) ) {
            $methods[] = __( 'Pickup', 'persiano-hub' );
        }
        if ( ! empty( $details['delivery'] ) ) {
            $methods[] = __( 'Local delivery', 'persiano-hub' );
        }
        if ( ! empty( $details['shipping'] ) ) {
            $methods[] = __( 'Shipping', 'persiano-hub' );
        }
        return implode( ' · ', $methods );
    }

    private static function format_date( $value ) {
        try {
            $date = new DateTimeImmutable( $value . ' 12:00:00', wp_timezone() );
            return wp_date( 'l, M j', $date->getTimestamp(), wp_timezone() );
        } catch ( Exception $e ) {
            return sanitize_text_field( $value );
        }
    }
}
