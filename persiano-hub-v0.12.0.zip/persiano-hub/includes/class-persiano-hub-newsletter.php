<?php
/**
 * Mailing list management for Persiano Hub.
 *
 * @package Persiano_Hub
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Persiano_Hub_Newsletter {
    const TABLE_SUFFIX = 'persiano_subscribers';
    const CHECKOUT_FIELD_ID = 'persiano-hub/newsletter-opt-in';

    public static function init() {
        add_shortcode( 'persiano_newsletter_signup', array( __CLASS__, 'shortcode' ) );

        add_action( 'admin_post_nopriv_persiano_newsletter_subscribe', array( __CLASS__, 'handle_subscribe' ) );
        add_action( 'admin_post_persiano_newsletter_subscribe', array( __CLASS__, 'handle_subscribe' ) );
        add_action( 'admin_post_nopriv_persiano_newsletter_unsubscribe', array( __CLASS__, 'handle_unsubscribe' ) );
        add_action( 'admin_post_persiano_newsletter_unsubscribe', array( __CLASS__, 'handle_unsubscribe' ) );

        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_post_persiano_newsletter_export', array( __CLASS__, 'export_csv' ) );

        // Classic checkout.
        add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'render_classic_checkout_opt_in' ), 8 );
        add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'process_classic_checkout_opt_in' ), 20, 3 );

        // Cart/Checkout block.
        add_action( 'woocommerce_init', array( __CLASS__, 'register_block_checkout_field' ) );
        add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'process_block_checkout_opt_in' ), 20, 1 );

        // Make subscription available to themes without coupling to a shortcode.
        add_action( 'persiano_hub_newsletter_form', array( __CLASS__, 'render_form' ) );
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    public static function install() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            email varchar(190) NOT NULL,
            name varchar(190) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'subscribed',
            source varchar(80) NOT NULL DEFAULT 'website',
            consent_text text NULL,
            consent_at datetime NULL,
            consent_ip varchar(100) NOT NULL DEFAULT '',
            consent_user_agent text NULL,
            unsubscribed_at datetime NULL,
            token varchar(64) NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            UNIQUE KEY token (token),
            KEY status (status)
        ) {$charset_collate};";

        dbDelta( $sql );
    }

    public static function consent_text() {
        return __( 'Yes, send me Persiano Dish menus, pantry updates, events and special offers by email. I can unsubscribe at any time.', 'persiano-hub' );
    }

    public static function subscribe( $email, $name = '', $source = 'website', $context = array() ) {
        global $wpdb;

        $email = sanitize_email( $email );
        $name = sanitize_text_field( $name );
        $source = sanitize_key( $source );

        if ( ! is_email( $email ) ) {
            return new WP_Error( 'invalid_email', __( 'Please enter a valid email address.', 'persiano-hub' ) );
        }

        $now = current_time( 'mysql' );
        $table = self::table_name();
        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s", $email ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $data = array(
            'name'               => $name,
            'status'             => 'subscribed',
            'source'             => $source ?: 'website',
            'consent_text'       => isset( $context['consent_text'] ) ? sanitize_textarea_field( $context['consent_text'] ) : self::consent_text(),
            'consent_at'         => $now,
            'consent_ip'         => isset( $context['ip'] ) ? sanitize_text_field( $context['ip'] ) : self::request_ip(),
            'consent_user_agent' => isset( $context['user_agent'] ) ? sanitize_textarea_field( $context['user_agent'] ) : self::request_user_agent(),
            'unsubscribed_at'    => null,
            'updated_at'         => $now,
        );

        if ( $existing ) {
            if ( ! $data['name'] ) {
                unset( $data['name'] );
            }
            $wpdb->update( $table, $data, array( 'id' => absint( $existing->id ) ) );
            return absint( $existing->id );
        }

        $data['email'] = $email;
        $data['token'] = wp_generate_password( 48, false, false );
        $data['created_at'] = $now;
        $wpdb->insert( $table, $data );

        if ( ! $wpdb->insert_id ) {
            return new WP_Error( 'db_error', __( 'We could not save your subscription. Please try again.', 'persiano-hub' ) );
        }

        return absint( $wpdb->insert_id );
    }

    public static function unsubscribe_by_token( $token ) {
        global $wpdb;
        $token = sanitize_text_field( $token );
        if ( ! $token ) {
            return false;
        }

        $table = self::table_name();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$table} WHERE token = %s", $token ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row ) {
            return false;
        }

        $now = current_time( 'mysql' );
        $wpdb->update(
            $table,
            array(
                'status'          => 'unsubscribed',
                'unsubscribed_at' => $now,
                'updated_at'      => $now,
            ),
            array( 'id' => absint( $row->id ) )
        );
        return true;
    }

    public static function get_unsubscribe_url( $email ) {
        global $wpdb;
        $table = self::table_name();
        $token = $wpdb->get_var( $wpdb->prepare( "SELECT token FROM {$table} WHERE email = %s", sanitize_email( $email ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $token ) {
            return '';
        }
        return add_query_arg(
            array(
                'action' => 'persiano_newsletter_unsubscribe',
                'token'  => rawurlencode( $token ),
            ),
            admin_url( 'admin-post.php' )
        );
    }

    public static function render_form( $args = array() ) {
        $args = wp_parse_args(
            $args,
            array(
                'source'      => 'website',
                'title'       => __( 'Be first to know what’s cooking.', 'persiano-hub' ),
                'description' => __( 'Get new weekly menus, pantry drops and Persiano events in your inbox.', 'persiano-hub' ),
                'compact'     => false,
            )
        );

        $status = isset( $_GET['persiano_subscribe'] ) ? sanitize_key( wp_unslash( $_GET['persiano_subscribe'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ?>
        <section class="ph-newsletter<?php echo $args['compact'] ? ' ph-newsletter--compact' : ''; ?>">
            <div class="ph-newsletter-copy">
                <span class="ph-newsletter-eyebrow"><?php esc_html_e( 'The Persiano List', 'persiano-hub' ); ?></span>
                <h2><?php echo esc_html( $args['title'] ); ?></h2>
                <p><?php echo esc_html( $args['description'] ); ?></p>
            </div>
            <div class="ph-newsletter-form-wrap">
                <?php if ( 'success' === $status ) : ?>
                    <div class="ph-newsletter-message ph-newsletter-message--success"><?php esc_html_e( 'You’re on the list. We’ll keep it useful and delicious.', 'persiano-hub' ); ?></div>
                <?php elseif ( 'error' === $status ) : ?>
                    <div class="ph-newsletter-message ph-newsletter-message--error"><?php esc_html_e( 'Something went wrong. Please check your email and try again.', 'persiano-hub' ); ?></div>
                <?php endif; ?>
                <form class="ph-newsletter-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="persiano_newsletter_subscribe">
                    <input type="hidden" name="source" value="<?php echo esc_attr( $args['source'] ); ?>">
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url( self::current_url() ); ?>">
                    <?php wp_nonce_field( 'persiano_newsletter_subscribe', 'persiano_newsletter_nonce' ); ?>
                    <div class="ph-newsletter-fields">
                        <label>
                            <span class="screen-reader-text"><?php esc_html_e( 'First name', 'persiano-hub' ); ?></span>
                            <input type="text" name="name" autocomplete="given-name" placeholder="<?php esc_attr_e( 'First name', 'persiano-hub' ); ?>">
                        </label>
                        <label>
                            <span class="screen-reader-text"><?php esc_html_e( 'Email address', 'persiano-hub' ); ?></span>
                            <input type="email" name="email" autocomplete="email" placeholder="<?php esc_attr_e( 'Email address', 'persiano-hub' ); ?>" required>
                        </label>
                        <button type="submit"><?php esc_html_e( 'Join the List', 'persiano-hub' ); ?></button>
                    </div>
                    <label class="ph-newsletter-consent">
                        <input type="checkbox" name="consent" value="yes" required>
                        <span><?php echo esc_html( self::consent_text() ); ?></span>
                    </label>
                </form>
            </div>
        </section>
        <?php
    }

    public static function shortcode( $atts ) {
        $atts = shortcode_atts(
            array(
                'source' => 'shortcode',
                'title'  => '',
            ),
            $atts,
            'persiano_newsletter_signup'
        );
        ob_start();
        self::render_form(
            array(
                'source' => $atts['source'],
                'title'  => $atts['title'] ?: __( 'Be first to know what’s cooking.', 'persiano-hub' ),
            )
        );
        return ob_get_clean();
    }

    public static function handle_subscribe() {
        $nonce = isset( $_POST['persiano_newsletter_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['persiano_newsletter_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'persiano_newsletter_subscribe' ) ) {
            wp_die( esc_html__( 'The form expired. Please go back and try again.', 'persiano-hub' ), 403 );
        }

        $redirect = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : home_url( '/' );
        $consent = isset( $_POST['consent'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['consent'] ) );
        if ( ! $consent ) {
            wp_safe_redirect( add_query_arg( 'persiano_subscribe', 'error', $redirect ) );
            exit;
        }

        $result = self::subscribe(
            isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '',
            isset( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : '',
            isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : 'website'
        );

        wp_safe_redirect( add_query_arg( 'persiano_subscribe', is_wp_error( $result ) ? 'error' : 'success', $redirect ) );
        exit;
    }

    public static function handle_unsubscribe() {
        $token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $success = self::unsubscribe_by_token( $token );

        wp_die(
            $success
                ? '<h1>' . esc_html__( 'You’re unsubscribed.', 'persiano-hub' ) . '</h1><p>' . esc_html__( 'You will no longer receive Persiano Dish marketing emails.', 'persiano-hub' ) . '</p>'
                : '<h1>' . esc_html__( 'We could not find that subscription.', 'persiano-hub' ) . '</h1>',
            esc_html__( 'Persiano Dish Mailing List', 'persiano-hub' ),
            array( 'response' => $success ? 200 : 404 )
        );
    }

    public static function register_block_checkout_field() {
        if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
            return;
        }

        woocommerce_register_additional_checkout_field(
            array(
                'id'            => self::CHECKOUT_FIELD_ID,
                'label'         => self::consent_text(),
                'optionalLabel' => self::consent_text(),
                'location'      => 'contact',
                'type'          => 'checkbox',
                'required'      => false,
            )
        );
    }

    public static function render_classic_checkout_opt_in() {
        ?>
        <div class="ph-checkout-newsletter">
            <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="persiano_newsletter_opt_in" value="1">
                <span><?php echo esc_html( self::consent_text() ); ?></span>
            </label>
        </div>
        <?php
    }

    public static function process_classic_checkout_opt_in( $order_id, $posted_data = array(), $order = null ) {
        if ( empty( $_POST['persiano_newsletter_opt_in'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            return;
        }
        $order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
        self::subscribe_from_order( $order, 'checkout' );
    }

    public static function process_block_checkout_opt_in( $order ) {
        if ( ! $order instanceof WC_Order ) {
            return;
        }

        $value = $order->get_meta( '_wc_other/' . self::CHECKOUT_FIELD_ID, true );
        if ( '1' === (string) $value || true === $value || 1 === $value ) {
            self::subscribe_from_order( $order, 'checkout' );
        }
    }

    private static function subscribe_from_order( $order, $source ) {
        if ( ! $order instanceof WC_Order ) {
            return;
        }
        $email = $order->get_billing_email();
        $name = trim( $order->get_billing_first_name() );
        if ( $email ) {
            self::subscribe( $email, $name, $source );
        }
    }

    public static function admin_menu() {
        add_submenu_page(
            'woocommerce',
            __( 'Persiano Mailing List', 'persiano-hub' ),
            __( 'Mailing List', 'persiano-hub' ),
            'manage_woocommerce',
            'persiano-mailing-list',
            array( __CLASS__, 'render_admin_page' )
        );
    }

    public static function render_admin_page() {
        global $wpdb;
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }
        $table = self::table_name();
        $subscribers = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY updated_at DESC LIMIT 500" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
        $active_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'subscribed'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Persiano Mailing List', 'persiano-hub' ); ?></h1>
            <p><?php echo esc_html( sprintf( __( '%d active subscribers. Consent source and timestamps are retained for your records.', 'persiano-hub' ), $active_count ) ); ?></p>
            <p>
                <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=persiano_newsletter_export' ), 'persiano_newsletter_export' ) ); ?>"><?php esc_html_e( 'Export CSV', 'persiano-hub' ); ?></a>
            </p>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e( 'Email', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Name', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Status', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Source', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Consent date', 'persiano-hub' ); ?></th></tr></thead>
                <tbody>
                <?php if ( $subscribers ) : foreach ( $subscribers as $subscriber ) : ?>
                    <tr>
                        <td><?php echo esc_html( $subscriber->email ); ?></td>
                        <td><?php echo esc_html( $subscriber->name ); ?></td>
                        <td><?php echo esc_html( ucfirst( $subscriber->status ) ); ?></td>
                        <td><?php echo esc_html( $subscriber->source ); ?></td>
                        <td><?php echo esc_html( $subscriber->consent_at ?: $subscriber->created_at ); ?></td>
                    </tr>
                <?php endforeach; else : ?>
                    <tr><td colspan="5"><?php esc_html_e( 'No subscribers yet.', 'persiano-hub' ); ?></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function export_csv() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to export subscribers.', 'persiano-hub' ), 403 );
        }
        check_admin_referer( 'persiano_newsletter_export' );

        global $wpdb;
        $table = self::table_name();
        $rows = $wpdb->get_results( "SELECT email, name, status, source, consent_at, unsubscribed_at FROM {$table} ORDER BY updated_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=persiano-mailing-list-' . gmdate( 'Y-m-d' ) . '.csv' );
        $output = fopen( 'php://output', 'w' );
        fputcsv( $output, array( 'Email', 'Name', 'Status', 'Source', 'Consent Date', 'Unsubscribed Date' ) );
        foreach ( $rows as $row ) {
            fputcsv( $output, $row );
        }
        fclose( $output );
        exit;
    }

    private static function request_ip() {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
        return sanitize_text_field( $ip );
    }

    private static function request_user_agent() {
        $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
        return sanitize_textarea_field( $ua );
    }

    private static function current_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : wp_parse_url( home_url(), PHP_URL_HOST );
        $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        return esc_url_raw( $scheme . $host . $uri );
    }
}
