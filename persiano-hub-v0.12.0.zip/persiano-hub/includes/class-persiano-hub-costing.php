<?php
/**
 * Persiano Ingredients, Recipes and Pricing.
 *
 * Provides an ingredient cost database, structured recipe costing, WooCommerce
 * product links, suggested tax-inclusive selling prices and a compact costing
 * dashboard. The older Persiano Pricing plugin, when present, is left untouched.
 *
 * @package Persiano_Hub
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Persiano_Hub_Costing {
    const INGREDIENT_POST_TYPE = 'persiano_ing';
    const RECIPE_POST_TYPE     = 'persiano_recipe';
    const MENU_SLUG            = 'persiano-hub-costing';

    const PRODUCT_RECIPE_META = '_persiano_recipe_id';

    const ING_CATEGORY      = '_persiano_ing_category';
    const ING_PURCHASE_QTY  = '_persiano_ing_purchase_qty';
    const ING_PURCHASE_UNIT = '_persiano_ing_purchase_unit';
    const ING_PURCHASE_COST = '_persiano_ing_purchase_cost';
    const ING_WASTE_PCT     = '_persiano_ing_waste_pct';
    const ING_SUPPLIER      = '_persiano_ing_supplier';
    const ING_NOTES         = '_persiano_ing_notes';
    const ING_UNIT_COST     = '_persiano_ing_unit_cost';
    const ING_BASE_UNIT     = '_persiano_ing_base_unit';
    const ING_HISTORY       = '_persiano_ing_cost_history';

    const RECIPE_PRODUCT_ID       = '_persiano_recipe_product_id';
    const RECIPE_YIELD_QTY        = '_persiano_recipe_yield_qty';
    const RECIPE_YIELD_LABEL      = '_persiano_recipe_yield_label';
    const RECIPE_ITEMS            = '_persiano_recipe_items';
    const RECIPE_PACKAGING_COST   = '_persiano_recipe_packaging_cost';
    const RECIPE_LABOUR_MINUTES   = '_persiano_recipe_labour_minutes';
    const RECIPE_LABOUR_RATE      = '_persiano_recipe_labour_rate';
    const RECIPE_OTHER_COST       = '_persiano_recipe_other_cost';
    const RECIPE_OVERHEAD_PCT     = '_persiano_recipe_overhead_pct';
    const RECIPE_TARGET_COST_PCT  = '_persiano_recipe_target_food_cost_pct';
    const RECIPE_INGREDIENT_COST  = '_persiano_recipe_ingredient_cost';
    const RECIPE_LABOUR_COST      = '_persiano_recipe_labour_cost';
    const RECIPE_OVERHEAD_COST    = '_persiano_recipe_overhead_cost';
    const RECIPE_BATCH_COST       = '_persiano_recipe_batch_cost';
    const RECIPE_COST_PER_SERVING = '_persiano_recipe_cost_per_serving';
    const RECIPE_SUGGESTED_PRICE  = '_persiano_recipe_suggested_price';
    const RECIPE_WARNINGS         = '_persiano_recipe_cost_warnings';

    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_types' ), 12 );
        add_action( 'admin_menu', array( __CLASS__, 'register_dashboard_page' ), 35 );

        add_action( 'add_meta_boxes_' . self::INGREDIENT_POST_TYPE, array( __CLASS__, 'ingredient_meta_boxes' ) );
        add_action( 'add_meta_boxes_' . self::RECIPE_POST_TYPE, array( __CLASS__, 'recipe_meta_boxes' ) );
        add_action( 'save_post_' . self::INGREDIENT_POST_TYPE, array( __CLASS__, 'save_ingredient' ), 10, 3 );
        add_action( 'save_post_' . self::RECIPE_POST_TYPE, array( __CLASS__, 'save_recipe' ), 10, 3 );

        add_filter( 'manage_' . self::INGREDIENT_POST_TYPE . '_posts_columns', array( __CLASS__, 'ingredient_columns' ) );
        add_action( 'manage_' . self::INGREDIENT_POST_TYPE . '_posts_custom_column', array( __CLASS__, 'ingredient_column_content' ), 10, 2 );
        add_filter( 'manage_' . self::RECIPE_POST_TYPE . '_posts_columns', array( __CLASS__, 'recipe_columns' ) );
        add_action( 'manage_' . self::RECIPE_POST_TYPE . '_posts_custom_column', array( __CLASS__, 'recipe_column_content' ), 10, 2 );

        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_action( 'add_meta_boxes_product', array( __CLASS__, 'product_costing_meta_box' ) );
        add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_product_recipe_link' ) );
        add_action( 'admin_post_persiano_hub_apply_suggested_price', array( __CLASS__, 'apply_suggested_price' ) );
    }

    private static function capabilities() {
        return array(
            'edit_post'              => 'manage_woocommerce',
            'read_post'              => 'manage_woocommerce',
            'delete_post'            => 'manage_woocommerce',
            'edit_posts'             => 'manage_woocommerce',
            'edit_others_posts'      => 'manage_woocommerce',
            'publish_posts'          => 'manage_woocommerce',
            'read_private_posts'     => 'manage_woocommerce',
            'delete_posts'           => 'manage_woocommerce',
            'delete_private_posts'   => 'manage_woocommerce',
            'delete_published_posts' => 'manage_woocommerce',
            'delete_others_posts'    => 'manage_woocommerce',
            'edit_private_posts'     => 'manage_woocommerce',
            'edit_published_posts'   => 'manage_woocommerce',
            'create_posts'           => 'manage_woocommerce',
        );
    }

    public static function register_post_types() {
        register_post_type(
            self::INGREDIENT_POST_TYPE,
            array(
                'labels' => array(
                    'name'               => __( 'Ingredients', 'persiano-hub' ),
                    'singular_name'      => __( 'Ingredient', 'persiano-hub' ),
                    'menu_name'          => __( 'Ingredients', 'persiano-hub' ),
                    'add_new'            => __( 'Add Ingredient', 'persiano-hub' ),
                    'add_new_item'       => __( 'Add Ingredient', 'persiano-hub' ),
                    'edit_item'          => __( 'Edit Ingredient', 'persiano-hub' ),
                    'new_item'           => __( 'New Ingredient', 'persiano-hub' ),
                    'search_items'       => __( 'Search Ingredients', 'persiano-hub' ),
                    'not_found'          => __( 'No ingredients found.', 'persiano-hub' ),
                    'all_items'          => __( 'Ingredients', 'persiano-hub' ),
                ),
                'public'             => false,
                'show_ui'            => true,
                'show_in_menu'       => 'persiano-hub',
                'show_in_rest'       => false,
                'supports'           => array( 'title' ),
                'capabilities'       => self::capabilities(),
                'map_meta_cap'       => false,
                'exclude_from_search'=> true,
                'publicly_queryable' => false,
                'query_var'          => false,
                'rewrite'            => false,
                'menu_position'      => 15,
            )
        );

        register_post_type(
            self::RECIPE_POST_TYPE,
            array(
                'labels' => array(
                    'name'               => __( 'Recipes & Pricing', 'persiano-hub' ),
                    'singular_name'      => __( 'Recipe', 'persiano-hub' ),
                    'menu_name'          => __( 'Recipes & Pricing', 'persiano-hub' ),
                    'add_new'            => __( 'Add Recipe', 'persiano-hub' ),
                    'add_new_item'       => __( 'Add Recipe & Costing', 'persiano-hub' ),
                    'edit_item'          => __( 'Edit Recipe & Costing', 'persiano-hub' ),
                    'new_item'           => __( 'New Recipe', 'persiano-hub' ),
                    'search_items'       => __( 'Search Recipes', 'persiano-hub' ),
                    'not_found'          => __( 'No recipes found.', 'persiano-hub' ),
                    'all_items'          => __( 'Recipes & Pricing', 'persiano-hub' ),
                ),
                'public'             => false,
                'show_ui'            => true,
                'show_in_menu'       => 'persiano-hub',
                'show_in_rest'       => false,
                'supports'           => array( 'title' ),
                'capabilities'       => self::capabilities(),
                'map_meta_cap'       => false,
                'exclude_from_search'=> true,
                'publicly_queryable' => false,
                'query_var'          => false,
                'rewrite'            => false,
                'menu_position'      => 16,
            )
        );
    }

    public static function register_dashboard_page() {
        add_submenu_page(
            'persiano-hub',
            __( 'Pricing & Costing', 'persiano-hub' ),
            __( 'Pricing & Costing', 'persiano-hub' ),
            'manage_woocommerce',
            self::MENU_SLUG,
            array( __CLASS__, 'render_dashboard_page' )
        );
    }

    public static function unit_options() {
        return array(
            'g'    => __( 'g', 'persiano-hub' ),
            'kg'   => __( 'kg', 'persiano-hub' ),
            'oz'   => __( 'oz', 'persiano-hub' ),
            'lb'   => __( 'lb', 'persiano-hub' ),
            'ml'   => __( 'ml', 'persiano-hub' ),
            'l'    => __( 'L', 'persiano-hub' ),
            'tsp'  => __( 'tsp', 'persiano-hub' ),
            'tbsp' => __( 'tbsp', 'persiano-hub' ),
            'cup'  => __( 'cup', 'persiano-hub' ),
            'each' => __( 'each', 'persiano-hub' ),
        );
    }

    private static function unit_family( $unit ) {
        if ( in_array( $unit, array( 'g', 'kg', 'oz', 'lb' ), true ) ) {
            return 'mass';
        }
        if ( in_array( $unit, array( 'ml', 'l', 'tsp', 'tbsp', 'cup' ), true ) ) {
            return 'volume';
        }
        if ( 'each' === $unit ) {
            return 'count';
        }
        return '';
    }

    private static function base_unit( $unit ) {
        $family = self::unit_family( $unit );
        if ( 'mass' === $family ) {
            return 'g';
        }
        if ( 'volume' === $family ) {
            return 'ml';
        }
        if ( 'count' === $family ) {
            return 'each';
        }
        return '';
    }

    private static function unit_multiplier( $unit ) {
        $multipliers = array(
            'g'    => 1,
            'kg'   => 1000,
            'oz'   => 28.349523125,
            'lb'   => 453.59237,
            'ml'   => 1,
            'l'    => 1000,
            'tsp'  => 5,
            'tbsp' => 15,
            'cup'  => 250,
            'each' => 1,
        );
        return isset( $multipliers[ $unit ] ) ? (float) $multipliers[ $unit ] : 0;
    }

    private static function normalize_amount( $quantity, $unit, $expected_base_unit ) {
        $quantity = (float) $quantity;
        $base     = self::base_unit( $unit );
        if ( $quantity < 0 || ! $base || $base !== $expected_base_unit ) {
            return null;
        }
        return $quantity * self::unit_multiplier( $unit );
    }

    private static function decimal( $value, $default = 0 ) {
        if ( is_string( $value ) ) {
            $value = str_replace( ',', '.', $value );
        }
        return is_numeric( $value ) ? (float) $value : (float) $default;
    }

    private static function money( $value ) {
        if ( function_exists( 'wc_price' ) ) {
            return wc_price( (float) $value );
        }
        return '$' . number_format_i18n( (float) $value, 2 );
    }

    public static function ingredient_meta_boxes() {
        add_meta_box(
            'persiano_hub_ingredient_costing',
            __( 'Ingredient Cost', 'persiano-hub' ),
            array( __CLASS__, 'render_ingredient_meta_box' ),
            self::INGREDIENT_POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'persiano_hub_ingredient_history',
            __( 'Recent Cost History', 'persiano-hub' ),
            array( __CLASS__, 'render_ingredient_history_meta_box' ),
            self::INGREDIENT_POST_TYPE,
            'side',
            'default'
        );
    }

    public static function render_ingredient_meta_box( $post ) {
        wp_nonce_field( 'persiano_hub_save_ingredient', 'persiano_hub_ingredient_nonce' );

        $category      = get_post_meta( $post->ID, self::ING_CATEGORY, true );
        $purchase_qty  = get_post_meta( $post->ID, self::ING_PURCHASE_QTY, true );
        $purchase_unit = get_post_meta( $post->ID, self::ING_PURCHASE_UNIT, true );
        $purchase_cost = get_post_meta( $post->ID, self::ING_PURCHASE_COST, true );
        $waste_pct     = get_post_meta( $post->ID, self::ING_WASTE_PCT, true );
        $supplier      = get_post_meta( $post->ID, self::ING_SUPPLIER, true );
        $notes         = get_post_meta( $post->ID, self::ING_NOTES, true );
        $unit_cost     = (float) get_post_meta( $post->ID, self::ING_UNIT_COST, true );
        $base_unit     = get_post_meta( $post->ID, self::ING_BASE_UNIT, true );

        if ( ! $purchase_unit ) {
            $purchase_unit = 'kg';
        }
        ?>
        <div class="ph-costing-grid ph-costing-grid--2">
            <div class="ph-costing-field">
                <label for="persiano_ing_category"><?php esc_html_e( 'Category', 'persiano-hub' ); ?></label>
                <input type="text" class="widefat" id="persiano_ing_category" name="persiano_ing_category" value="<?php echo esc_attr( $category ); ?>" placeholder="<?php esc_attr_e( 'Produce, meat, dairy, packaging…', 'persiano-hub' ); ?>">
            </div>
            <div class="ph-costing-field">
                <label for="persiano_ing_supplier"><?php esc_html_e( 'Supplier / store', 'persiano-hub' ); ?></label>
                <input type="text" class="widefat" id="persiano_ing_supplier" name="persiano_ing_supplier" value="<?php echo esc_attr( $supplier ); ?>" placeholder="<?php esc_attr_e( 'Optional', 'persiano-hub' ); ?>">
            </div>
            <div class="ph-costing-field">
                <label for="persiano_ing_purchase_qty"><?php esc_html_e( 'Purchase quantity', 'persiano-hub' ); ?></label>
                <input type="number" min="0" step="0.0001" class="widefat ph-ing-live" id="persiano_ing_purchase_qty" name="persiano_ing_purchase_qty" value="<?php echo esc_attr( $purchase_qty ); ?>" placeholder="10">
            </div>
            <div class="ph-costing-field">
                <label for="persiano_ing_purchase_unit"><?php esc_html_e( 'Purchase unit', 'persiano-hub' ); ?></label>
                <select class="widefat ph-ing-live" id="persiano_ing_purchase_unit" name="persiano_ing_purchase_unit">
                    <?php foreach ( self::unit_options() as $value => $label ) : ?>
                        <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $purchase_unit, $value ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ph-costing-field">
                <label for="persiano_ing_purchase_cost"><?php esc_html_e( 'What you paid', 'persiano-hub' ); ?></label>
                <input type="number" min="0" step="0.01" class="widefat ph-ing-live" id="persiano_ing_purchase_cost" name="persiano_ing_purchase_cost" value="<?php echo esc_attr( $purchase_cost ); ?>" placeholder="25.00">
                <p class="description"><?php esc_html_e( 'Enter the actual package cost you want Persiano to use for costing.', 'persiano-hub' ); ?></p>
            </div>
            <div class="ph-costing-field">
                <label for="persiano_ing_waste_pct"><?php esc_html_e( 'Estimated waste / trim', 'persiano-hub' ); ?></label>
                <div class="ph-input-suffix"><input type="number" min="0" max="99" step="0.1" class="widefat ph-ing-live" id="persiano_ing_waste_pct" name="persiano_ing_waste_pct" value="<?php echo esc_attr( $waste_pct ); ?>" placeholder="0"><span>%</span></div>
                <p class="description"><?php esc_html_e( 'Optional. Example: peel, bones, trimming or unusable product.', 'persiano-hub' ); ?></p>
            </div>
        </div>

        <div class="ph-cost-summary ph-cost-summary--ingredient">
            <div><span><?php esc_html_e( 'Usable cost', 'persiano-hub' ); ?></span><strong id="ph-live-unit-cost"><?php echo $unit_cost > 0 ? wp_kses_post( self::money( $unit_cost ) . ' / ' . esc_html( $base_unit ) ) : '—'; ?></strong></div>
            <div><span><?php esc_html_e( 'Equivalent', 'persiano-hub' ); ?></span><strong id="ph-live-equivalent"><?php echo $unit_cost > 0 && in_array( $base_unit, array( 'g', 'ml' ), true ) ? wp_kses_post( self::money( $unit_cost * 1000 ) . ( 'g' === $base_unit ? ' / kg' : ' / L' ) ) : '—'; ?></strong></div>
        </div>

        <div class="ph-costing-field ph-costing-field--full">
            <label for="persiano_ing_notes"><?php esc_html_e( 'Notes', 'persiano-hub' ); ?></label>
            <textarea class="widefat" rows="4" id="persiano_ing_notes" name="persiano_ing_notes"><?php echo esc_textarea( $notes ); ?></textarea>
        </div>
        <?php
    }

    public static function render_ingredient_history_meta_box( $post ) {
        $history = get_post_meta( $post->ID, self::ING_HISTORY, true );
        $history = is_array( $history ) ? array_reverse( $history ) : array();
        $history = array_slice( $history, 0, 6 );

        if ( ! $history ) {
            echo '<p>' . esc_html__( 'Cost changes will appear here after you save this ingredient.', 'persiano-hub' ) . '</p>';
            return;
        }

        echo '<div class="ph-history-list">';
        foreach ( $history as $entry ) {
            $date      = ! empty( $entry['time'] ) ? wp_date( 'M j, Y', absint( $entry['time'] ) ) : '';
            $unit_cost = isset( $entry['unit_cost'] ) ? (float) $entry['unit_cost'] : 0;
            $base_unit = ! empty( $entry['base_unit'] ) ? $entry['base_unit'] : '';
            echo '<div class="ph-history-entry">';
            echo '<strong>' . wp_kses_post( self::money( isset( $entry['purchase_cost'] ) ? $entry['purchase_cost'] : 0 ) ) . '</strong>';
            echo '<span>' . esc_html( isset( $entry['purchase_qty'] ) ? $entry['purchase_qty'] : '' ) . ' ' . esc_html( isset( $entry['purchase_unit'] ) ? $entry['purchase_unit'] : '' ) . '</span>';
            if ( $unit_cost > 0 ) {
                echo '<small>' . wp_kses_post( self::money( $unit_cost ) ) . ' / ' . esc_html( $base_unit ) . '</small>';
            }
            echo '<small>' . esc_html( $date ) . '</small>';
            echo '</div>';
        }
        echo '</div>';
    }

    public static function save_ingredient( $post_id, $post, $update ) {
        if ( ! self::can_save_post( $post_id, 'persiano_hub_ingredient_nonce', 'persiano_hub_save_ingredient' ) ) {
            return;
        }

        $old_snapshot = array(
            'purchase_qty'  => get_post_meta( $post_id, self::ING_PURCHASE_QTY, true ),
            'purchase_unit' => get_post_meta( $post_id, self::ING_PURCHASE_UNIT, true ),
            'purchase_cost' => get_post_meta( $post_id, self::ING_PURCHASE_COST, true ),
            'waste_pct'     => get_post_meta( $post_id, self::ING_WASTE_PCT, true ),
        );

        $category      = isset( $_POST['persiano_ing_category'] ) ? sanitize_text_field( wp_unslash( $_POST['persiano_ing_category'] ) ) : '';
        $purchase_qty  = isset( $_POST['persiano_ing_purchase_qty'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_ing_purchase_qty'] ) ) ) : 0;
        $purchase_unit = isset( $_POST['persiano_ing_purchase_unit'] ) ? sanitize_key( wp_unslash( $_POST['persiano_ing_purchase_unit'] ) ) : 'kg';
        $purchase_cost = isset( $_POST['persiano_ing_purchase_cost'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_ing_purchase_cost'] ) ) ) : 0;
        $waste_pct     = isset( $_POST['persiano_ing_waste_pct'] ) ? min( 99, max( 0, self::decimal( wp_unslash( $_POST['persiano_ing_waste_pct'] ) ) ) ) : 0;
        $supplier      = isset( $_POST['persiano_ing_supplier'] ) ? sanitize_text_field( wp_unslash( $_POST['persiano_ing_supplier'] ) ) : '';
        $notes         = isset( $_POST['persiano_ing_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['persiano_ing_notes'] ) ) : '';

        if ( ! array_key_exists( $purchase_unit, self::unit_options() ) ) {
            $purchase_unit = 'kg';
        }

        $base_unit = self::base_unit( $purchase_unit );
        $base_qty  = $purchase_qty * self::unit_multiplier( $purchase_unit );
        $usable    = $base_qty * ( 1 - ( $waste_pct / 100 ) );
        $unit_cost = $usable > 0 ? $purchase_cost / $usable : 0;

        update_post_meta( $post_id, self::ING_CATEGORY, $category );
        update_post_meta( $post_id, self::ING_PURCHASE_QTY, $purchase_qty );
        update_post_meta( $post_id, self::ING_PURCHASE_UNIT, $purchase_unit );
        update_post_meta( $post_id, self::ING_PURCHASE_COST, $purchase_cost );
        update_post_meta( $post_id, self::ING_WASTE_PCT, $waste_pct );
        update_post_meta( $post_id, self::ING_SUPPLIER, $supplier );
        update_post_meta( $post_id, self::ING_NOTES, $notes );
        update_post_meta( $post_id, self::ING_UNIT_COST, $unit_cost );
        update_post_meta( $post_id, self::ING_BASE_UNIT, $base_unit );

        $new_snapshot = array(
            'purchase_qty'  => $purchase_qty,
            'purchase_unit' => $purchase_unit,
            'purchase_cost' => $purchase_cost,
            'waste_pct'     => $waste_pct,
        );

        if ( ! $update || $old_snapshot !== $new_snapshot ) {
            $history = get_post_meta( $post_id, self::ING_HISTORY, true );
            $history = is_array( $history ) ? $history : array();
            $history[] = array(
                'time'          => time(),
                'purchase_qty'  => $purchase_qty,
                'purchase_unit' => $purchase_unit,
                'purchase_cost' => $purchase_cost,
                'waste_pct'     => $waste_pct,
                'unit_cost'     => $unit_cost,
                'base_unit'     => $base_unit,
            );
            if ( count( $history ) > 50 ) {
                $history = array_slice( $history, -50 );
            }
            update_post_meta( $post_id, self::ING_HISTORY, $history );
        }

        self::recalculate_all_recipes();
    }

    public static function recipe_meta_boxes() {
        add_meta_box(
            'persiano_hub_recipe_details',
            __( 'Recipe & Costing', 'persiano-hub' ),
            array( __CLASS__, 'render_recipe_meta_box' ),
            self::RECIPE_POST_TYPE,
            'normal',
            'high'
        );
    }

    private static function get_ingredients_for_select() {
        return get_posts(
            array(
                'post_type'      => self::INGREDIENT_POST_TYPE,
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            )
        );
    }

    private static function get_products_for_select() {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array();
        }
        return wc_get_products(
            array(
                'limit'   => -1,
                'status'  => array( 'publish', 'draft', 'private' ),
                'orderby' => 'name',
                'order'   => 'ASC',
                'return'  => 'objects',
            )
        );
    }

    private static function get_recipe_items( $recipe_id ) {
        $items = get_post_meta( $recipe_id, self::RECIPE_ITEMS, true );
        return is_array( $items ) ? $items : array();
    }

    public static function render_recipe_meta_box( $post ) {
        wp_nonce_field( 'persiano_hub_save_recipe', 'persiano_hub_recipe_nonce' );

        $product_id      = absint( get_post_meta( $post->ID, self::RECIPE_PRODUCT_ID, true ) );
        $yield_qty       = self::decimal( get_post_meta( $post->ID, self::RECIPE_YIELD_QTY, true ), 1 );
        $yield_label     = get_post_meta( $post->ID, self::RECIPE_YIELD_LABEL, true );
        $items           = self::get_recipe_items( $post->ID );
        $packaging_cost  = self::decimal( get_post_meta( $post->ID, self::RECIPE_PACKAGING_COST, true ) );
        $labour_minutes  = self::decimal( get_post_meta( $post->ID, self::RECIPE_LABOUR_MINUTES, true ) );
        $labour_rate     = self::decimal( get_post_meta( $post->ID, self::RECIPE_LABOUR_RATE, true ) );
        $other_cost      = self::decimal( get_post_meta( $post->ID, self::RECIPE_OTHER_COST, true ) );
        $overhead_pct    = self::decimal( get_post_meta( $post->ID, self::RECIPE_OVERHEAD_PCT, true ) );
        $target_cost_pct = self::decimal( get_post_meta( $post->ID, self::RECIPE_TARGET_COST_PCT, true ), 35 );
        $ingredients     = self::get_ingredients_for_select();
        $products        = self::get_products_for_select();
        $summary         = self::calculate_recipe( $post->ID );

        if ( ! $yield_label ) {
            $yield_label = __( 'servings', 'persiano-hub' );
        }
        if ( ! $items ) {
            $items = array( array( 'ingredient_id' => 0, 'qty' => '', 'unit' => 'g' ) );
        }
        ?>
        <div class="ph-costing-section">
            <h3><?php esc_html_e( 'Product & Yield', 'persiano-hub' ); ?></h3>
            <div class="ph-costing-grid ph-costing-grid--3">
                <div class="ph-costing-field ph-costing-field--wide">
                    <label for="persiano_recipe_product_id"><?php esc_html_e( 'Linked WooCommerce product', 'persiano-hub' ); ?></label>
                    <select class="widefat" id="persiano_recipe_product_id" name="persiano_recipe_product_id">
                        <option value="0"><?php esc_html_e( '— No linked product yet —', 'persiano-hub' ); ?></option>
                        <?php foreach ( $products as $product ) : ?>
                            <option value="<?php echo esc_attr( $product->get_id() ); ?>" <?php selected( $product_id, $product->get_id() ); ?>><?php echo esc_html( $product->get_name() . ' (#' . $product->get_id() . ')' ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Links this recipe to the item customers buy. Pricing can then compare the real cost with the current product price.', 'persiano-hub' ); ?></p>
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_yield_qty"><?php esc_html_e( 'Batch yield', 'persiano-hub' ); ?></label>
                    <input type="number" min="0.0001" step="0.01" class="widefat ph-recipe-live" id="persiano_recipe_yield_qty" name="persiano_recipe_yield_qty" value="<?php echo esc_attr( $yield_qty ); ?>">
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_yield_label"><?php esc_html_e( 'Yield label', 'persiano-hub' ); ?></label>
                    <input type="text" class="widefat" id="persiano_recipe_yield_label" name="persiano_recipe_yield_label" value="<?php echo esc_attr( $yield_label ); ?>" placeholder="servings">
                </div>
            </div>
        </div>

        <div class="ph-costing-section">
            <div class="ph-costing-heading-row">
                <div>
                    <h3><?php esc_html_e( 'Ingredients', 'persiano-hub' ); ?></h3>
                    <p><?php esc_html_e( 'Costs are pulled from the Ingredient database automatically.', 'persiano-hub' ); ?></p>
                </div>
                <button type="button" class="button" id="ph-add-recipe-ingredient"><?php esc_html_e( '+ Add ingredient', 'persiano-hub' ); ?></button>
            </div>

            <?php if ( ! $ingredients ) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e( 'Add at least one ingredient first. You can still save the recipe now and come back later.', 'persiano-hub' ); ?> <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::INGREDIENT_POST_TYPE ) ); ?>"><?php esc_html_e( 'Add ingredient', 'persiano-hub' ); ?></a></p></div>
            <?php endif; ?>

            <div class="ph-recipe-items" id="ph-recipe-items">
                <div class="ph-recipe-row ph-recipe-row--header"><span><?php esc_html_e( 'Ingredient', 'persiano-hub' ); ?></span><span><?php esc_html_e( 'Quantity', 'persiano-hub' ); ?></span><span><?php esc_html_e( 'Unit', 'persiano-hub' ); ?></span><span><?php esc_html_e( 'Cost', 'persiano-hub' ); ?></span><span></span></div>
                <?php foreach ( $items as $index => $item ) : ?>
                    <?php self::render_recipe_item_row( $index, $item, $ingredients ); ?>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="ph-costing-section">
            <h3><?php esc_html_e( 'Other Costs', 'persiano-hub' ); ?></h3>
            <div class="ph-costing-grid ph-costing-grid--3">
                <div class="ph-costing-field">
                    <label for="persiano_recipe_packaging_cost"><?php esc_html_e( 'Packaging / batch', 'persiano-hub' ); ?></label>
                    <input type="number" min="0" step="0.01" class="widefat ph-recipe-live" id="persiano_recipe_packaging_cost" name="persiano_recipe_packaging_cost" value="<?php echo esc_attr( $packaging_cost ); ?>">
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_labour_minutes"><?php esc_html_e( 'Labour minutes / batch', 'persiano-hub' ); ?></label>
                    <input type="number" min="0" step="1" class="widefat ph-recipe-live" id="persiano_recipe_labour_minutes" name="persiano_recipe_labour_minutes" value="<?php echo esc_attr( $labour_minutes ); ?>">
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_labour_rate"><?php esc_html_e( 'Labour rate / hour', 'persiano-hub' ); ?></label>
                    <input type="number" min="0" step="0.01" class="widefat ph-recipe-live" id="persiano_recipe_labour_rate" name="persiano_recipe_labour_rate" value="<?php echo esc_attr( $labour_rate ); ?>">
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_other_cost"><?php esc_html_e( 'Other fixed cost / batch', 'persiano-hub' ); ?></label>
                    <input type="number" min="0" step="0.01" class="widefat ph-recipe-live" id="persiano_recipe_other_cost" name="persiano_recipe_other_cost" value="<?php echo esc_attr( $other_cost ); ?>">
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_overhead_pct"><?php esc_html_e( 'Overhead', 'persiano-hub' ); ?></label>
                    <div class="ph-input-suffix"><input type="number" min="0" step="0.1" class="widefat ph-recipe-live" id="persiano_recipe_overhead_pct" name="persiano_recipe_overhead_pct" value="<?php echo esc_attr( $overhead_pct ); ?>"><span>%</span></div>
                </div>
                <div class="ph-costing-field">
                    <label for="persiano_recipe_target_food_cost_pct"><?php esc_html_e( 'Target cost percentage', 'persiano-hub' ); ?></label>
                    <div class="ph-input-suffix"><input type="number" min="1" max="99" step="0.1" class="widefat ph-recipe-live" id="persiano_recipe_target_food_cost_pct" name="persiano_recipe_target_food_cost_pct" value="<?php echo esc_attr( $target_cost_pct ); ?>"><span>%</span></div>
                    <p class="description"><?php esc_html_e( 'Used to calculate the suggested customer-facing price.', 'persiano-hub' ); ?></p>
                </div>
            </div>
        </div>

        <?php self::render_recipe_summary( $post->ID, $summary ); ?>

        <script type="text/template" id="ph-recipe-row-template">
            <?php self::render_recipe_item_row( '__INDEX__', array( 'ingredient_id' => 0, 'qty' => '', 'unit' => 'g' ), $ingredients ); ?>
        </script>
        <?php
    }

    private static function render_recipe_item_row( $index, $item, $ingredients ) {
        $ingredient_id = isset( $item['ingredient_id'] ) ? absint( $item['ingredient_id'] ) : 0;
        $qty           = isset( $item['qty'] ) ? $item['qty'] : '';
        $unit          = isset( $item['unit'] ) ? sanitize_key( $item['unit'] ) : 'g';
        ?>
        <div class="ph-recipe-row" data-index="<?php echo esc_attr( $index ); ?>">
            <select class="ph-recipe-ingredient widefat" name="persiano_recipe_items[<?php echo esc_attr( $index ); ?>][ingredient_id]">
                <option value="0"><?php esc_html_e( 'Select ingredient…', 'persiano-hub' ); ?></option>
                <?php foreach ( $ingredients as $ingredient ) :
                    $unit_cost = (float) get_post_meta( $ingredient->ID, self::ING_UNIT_COST, true );
                    $base_unit = get_post_meta( $ingredient->ID, self::ING_BASE_UNIT, true );
                    ?>
                    <option value="<?php echo esc_attr( $ingredient->ID ); ?>" data-unit-cost="<?php echo esc_attr( $unit_cost ); ?>" data-base-unit="<?php echo esc_attr( $base_unit ); ?>" <?php selected( $ingredient_id, $ingredient->ID ); ?>><?php echo esc_html( $ingredient->post_title ); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" min="0" step="0.0001" class="ph-recipe-qty widefat" name="persiano_recipe_items[<?php echo esc_attr( $index ); ?>][qty]" value="<?php echo esc_attr( $qty ); ?>">
            <select class="ph-recipe-unit widefat" name="persiano_recipe_items[<?php echo esc_attr( $index ); ?>][unit]">
                <?php foreach ( self::unit_options() as $value => $label ) : ?>
                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $unit, $value ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
            <strong class="ph-recipe-line-cost">—</strong>
            <button type="button" class="button-link-delete ph-remove-recipe-row" aria-label="<?php esc_attr_e( 'Remove ingredient', 'persiano-hub' ); ?>">×</button>
        </div>
        <?php
    }

    private static function render_recipe_summary( $recipe_id, $summary ) {
        $product_id    = absint( get_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, true ) );
        $product       = $product_id ? wc_get_product( $product_id ) : false;
        $current_price = $product ? self::decimal( $product->get_price() ) : 0;
        $net_price     = $product && $current_price > 0 && function_exists( 'wc_get_price_excluding_tax' ) ? (float) wc_get_price_excluding_tax( $product, array( 'qty' => 1, 'price' => $current_price ) ) : $current_price;
        $margin        = $net_price > 0 ? ( ( $net_price - $summary['cost_per_serving'] ) / $net_price ) * 100 : null;
        ?>
        <div class="ph-cost-summary ph-cost-summary--recipe" id="ph-recipe-summary" data-current-price="<?php echo esc_attr( $current_price ); ?>" data-tax-factor="<?php echo esc_attr( self::add_base_tax_to_price( 1, $product_id ) ); ?>">
            <div><span><?php esc_html_e( 'Ingredients', 'persiano-hub' ); ?></span><strong data-summary="ingredients"><?php echo wp_kses_post( self::money( $summary['ingredient_cost'] ) ); ?></strong></div>
            <div><span><?php esc_html_e( 'Labour', 'persiano-hub' ); ?></span><strong data-summary="labour"><?php echo wp_kses_post( self::money( $summary['labour_cost'] ) ); ?></strong></div>
            <div><span><?php esc_html_e( 'Total batch cost', 'persiano-hub' ); ?></span><strong data-summary="batch"><?php echo wp_kses_post( self::money( $summary['batch_cost'] ) ); ?></strong></div>
            <div><span><?php esc_html_e( 'Cost per serving', 'persiano-hub' ); ?></span><strong data-summary="per-serving"><?php echo wp_kses_post( self::money( $summary['cost_per_serving'] ) ); ?></strong></div>
            <div><span><?php esc_html_e( 'Current displayed price', 'persiano-hub' ); ?></span><strong><?php echo $current_price > 0 ? wp_kses_post( self::money( $current_price ) ) : '—'; ?></strong></div>
            <div class="ph-cost-summary__highlight"><span><?php esc_html_e( 'Suggested displayed price', 'persiano-hub' ); ?></span><strong data-summary="suggested"><?php echo wp_kses_post( self::money( $summary['suggested_price'] ) ); ?></strong></div>
            <div><span><?php esc_html_e( 'Estimated gross margin', 'persiano-hub' ); ?></span><strong><?php echo null !== $margin ? esc_html( number_format_i18n( $margin, 1 ) . '%' ) : '—'; ?></strong></div>
        </div>

        <?php if ( ! empty( $summary['warnings'] ) ) : ?>
            <div class="notice notice-warning inline ph-costing-warning"><p><strong><?php esc_html_e( 'Costing needs attention:', 'persiano-hub' ); ?></strong></p><ul>
                <?php foreach ( $summary['warnings'] as $warning ) : ?><li><?php echo esc_html( $warning ); ?></li><?php endforeach; ?>
            </ul></div>
        <?php endif; ?>

        <?php if ( $product && $summary['suggested_price'] > 0 ) : ?>
            <?php
            $url = wp_nonce_url(
                add_query_arg(
                    array(
                        'action'    => 'persiano_hub_apply_suggested_price',
                        'recipe_id' => $recipe_id,
                    ),
                    admin_url( 'admin-post.php' )
                ),
                'persiano_hub_apply_suggested_price_' . $recipe_id
            );
            ?>
            <p class="ph-apply-price-row"><a class="button button-primary" href="<?php echo esc_url( $url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Replace the linked product regular price with this suggested price?', 'persiano-hub' ) ); ?>');"><?php esc_html_e( 'Apply suggested price to product', 'persiano-hub' ); ?></a> <span><?php esc_html_e( 'The price is written to the WooCommerce product as the customer-facing, tax-inclusive regular price.', 'persiano-hub' ); ?></span></p>
        <?php endif; ?>
        <?php
    }

    public static function save_recipe( $post_id, $post, $update ) {
        if ( ! self::can_save_post( $post_id, 'persiano_hub_recipe_nonce', 'persiano_hub_save_recipe' ) ) {
            return;
        }

        $old_product_id = absint( get_post_meta( $post_id, self::RECIPE_PRODUCT_ID, true ) );
        $product_id     = isset( $_POST['persiano_recipe_product_id'] ) ? absint( $_POST['persiano_recipe_product_id'] ) : 0;
        $yield_qty      = isset( $_POST['persiano_recipe_yield_qty'] ) ? max( 0.0001, self::decimal( wp_unslash( $_POST['persiano_recipe_yield_qty'] ), 1 ) ) : 1;
        $yield_label    = isset( $_POST['persiano_recipe_yield_label'] ) ? sanitize_text_field( wp_unslash( $_POST['persiano_recipe_yield_label'] ) ) : 'servings';
        $packaging      = isset( $_POST['persiano_recipe_packaging_cost'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_recipe_packaging_cost'] ) ) ) : 0;
        $labour_minutes = isset( $_POST['persiano_recipe_labour_minutes'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_recipe_labour_minutes'] ) ) ) : 0;
        $labour_rate    = isset( $_POST['persiano_recipe_labour_rate'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_recipe_labour_rate'] ) ) ) : 0;
        $other_cost     = isset( $_POST['persiano_recipe_other_cost'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_recipe_other_cost'] ) ) ) : 0;
        $overhead_pct   = isset( $_POST['persiano_recipe_overhead_pct'] ) ? max( 0, self::decimal( wp_unslash( $_POST['persiano_recipe_overhead_pct'] ) ) ) : 0;
        $target_pct     = isset( $_POST['persiano_recipe_target_food_cost_pct'] ) ? min( 99, max( 1, self::decimal( wp_unslash( $_POST['persiano_recipe_target_food_cost_pct'] ), 35 ) ) ) : 35;

        $items = array();
        if ( isset( $_POST['persiano_recipe_items'] ) && is_array( $_POST['persiano_recipe_items'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            foreach ( wp_unslash( $_POST['persiano_recipe_items'] ) as $item ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                if ( ! is_array( $item ) ) {
                    continue;
                }
                $ingredient_id = isset( $item['ingredient_id'] ) ? absint( $item['ingredient_id'] ) : 0;
                $qty           = isset( $item['qty'] ) ? max( 0, self::decimal( $item['qty'] ) ) : 0;
                $unit          = isset( $item['unit'] ) ? sanitize_key( $item['unit'] ) : 'g';

                if ( ! $ingredient_id || $qty <= 0 || ! array_key_exists( $unit, self::unit_options() ) ) {
                    continue;
                }

                $items[] = array(
                    'ingredient_id' => $ingredient_id,
                    'qty'           => $qty,
                    'unit'          => $unit,
                );
            }
        }

        update_post_meta( $post_id, self::RECIPE_PRODUCT_ID, $product_id );
        update_post_meta( $post_id, self::RECIPE_YIELD_QTY, $yield_qty );
        update_post_meta( $post_id, self::RECIPE_YIELD_LABEL, $yield_label );
        update_post_meta( $post_id, self::RECIPE_ITEMS, $items );
        update_post_meta( $post_id, self::RECIPE_PACKAGING_COST, $packaging );
        update_post_meta( $post_id, self::RECIPE_LABOUR_MINUTES, $labour_minutes );
        update_post_meta( $post_id, self::RECIPE_LABOUR_RATE, $labour_rate );
        update_post_meta( $post_id, self::RECIPE_OTHER_COST, $other_cost );
        update_post_meta( $post_id, self::RECIPE_OVERHEAD_PCT, $overhead_pct );
        update_post_meta( $post_id, self::RECIPE_TARGET_COST_PCT, $target_pct );

        self::sync_recipe_product_link( $post_id, $product_id, $old_product_id );
        self::recalculate_recipe( $post_id );
    }

    private static function can_save_post( $post_id, $nonce_field, $nonce_action ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return false;
        }
        if ( wp_is_post_revision( $post_id ) ) {
            return false;
        }
        if ( ! isset( $_POST[ $nonce_field ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ), $nonce_action ) ) {
            return false;
        }
        return current_user_can( 'manage_woocommerce' );
    }

    private static function sync_recipe_product_link( $recipe_id, $product_id, $old_product_id = 0 ) {
        if ( $old_product_id && $old_product_id !== $product_id ) {
            $old_link = absint( get_post_meta( $old_product_id, self::PRODUCT_RECIPE_META, true ) );
            if ( $old_link === $recipe_id ) {
                delete_post_meta( $old_product_id, self::PRODUCT_RECIPE_META );
            }
        }

        if ( $product_id ) {
            update_post_meta( $product_id, self::PRODUCT_RECIPE_META, $recipe_id );
        }
    }

    public static function calculate_recipe( $recipe_id ) {
        $items           = self::get_recipe_items( $recipe_id );
        $yield_qty       = max( 0.0001, self::decimal( get_post_meta( $recipe_id, self::RECIPE_YIELD_QTY, true ), 1 ) );
        $packaging_cost  = max( 0, self::decimal( get_post_meta( $recipe_id, self::RECIPE_PACKAGING_COST, true ) ) );
        $labour_minutes  = max( 0, self::decimal( get_post_meta( $recipe_id, self::RECIPE_LABOUR_MINUTES, true ) ) );
        $labour_rate     = max( 0, self::decimal( get_post_meta( $recipe_id, self::RECIPE_LABOUR_RATE, true ) ) );
        $other_cost      = max( 0, self::decimal( get_post_meta( $recipe_id, self::RECIPE_OTHER_COST, true ) ) );
        $overhead_pct    = max( 0, self::decimal( get_post_meta( $recipe_id, self::RECIPE_OVERHEAD_PCT, true ) ) );
        $target_cost_pct = min( 99, max( 1, self::decimal( get_post_meta( $recipe_id, self::RECIPE_TARGET_COST_PCT, true ), 35 ) ) );
        $product_id      = absint( get_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, true ) );

        $ingredient_cost = 0;
        $warnings        = array();

        foreach ( $items as $item ) {
            $ingredient_id = isset( $item['ingredient_id'] ) ? absint( $item['ingredient_id'] ) : 0;
            $qty           = isset( $item['qty'] ) ? self::decimal( $item['qty'] ) : 0;
            $unit          = isset( $item['unit'] ) ? sanitize_key( $item['unit'] ) : '';
            $ingredient    = $ingredient_id ? get_post( $ingredient_id ) : null;

            if ( ! $ingredient || self::INGREDIENT_POST_TYPE !== $ingredient->post_type ) {
                continue;
            }

            $unit_cost = (float) get_post_meta( $ingredient_id, self::ING_UNIT_COST, true );
            $base_unit = get_post_meta( $ingredient_id, self::ING_BASE_UNIT, true );
            $normalized = self::normalize_amount( $qty, $unit, $base_unit );

            if ( null === $normalized ) {
                $warnings[] = sprintf(
                    /* translators: 1: ingredient name, 2: recipe unit, 3: ingredient base unit */
                    __( '%1$s uses %2$s, which cannot be converted to the ingredient cost unit (%3$s).', 'persiano-hub' ),
                    $ingredient->post_title,
                    $unit,
                    $base_unit ? $base_unit : __( 'unknown', 'persiano-hub' )
                );
                continue;
            }

            if ( $unit_cost <= 0 ) {
                $warnings[] = sprintf( __( '%s does not have a usable purchase cost yet.', 'persiano-hub' ), $ingredient->post_title );
                continue;
            }

            $ingredient_cost += $normalized * $unit_cost;
        }

        $labour_cost = ( $labour_minutes / 60 ) * $labour_rate;
        $base_cost   = $ingredient_cost + $packaging_cost + $labour_cost + $other_cost;
        $overhead    = $base_cost * ( $overhead_pct / 100 );
        $batch_cost  = $base_cost + $overhead;
        $per_serving = $batch_cost / $yield_qty;
        $net_target  = $per_serving / ( $target_cost_pct / 100 );
        $gross_target = self::add_base_tax_to_price( $net_target, $product_id );
        $suggested   = self::round_price( $gross_target, 0.50 );

        return array(
            'ingredient_cost' => $ingredient_cost,
            'labour_cost'     => $labour_cost,
            'overhead_cost'   => $overhead,
            'batch_cost'      => $batch_cost,
            'cost_per_serving'=> $per_serving,
            'suggested_price' => $suggested,
            'warnings'        => array_values( array_unique( $warnings ) ),
        );
    }

    private static function add_base_tax_to_price( $net_price, $product_id = 0 ) {
        if ( ! class_exists( 'WC_Tax' ) || $net_price <= 0 ) {
            return $net_price;
        }

        $tax_class = '';
        if ( $product_id ) {
            $product = wc_get_product( $product_id );
            if ( $product && $product->is_taxable() ) {
                $tax_class = $product->get_tax_class();
            } elseif ( $product && ! $product->is_taxable() ) {
                return $net_price;
            }
        }

        if ( method_exists( 'WC_Tax', 'get_base_tax_rates' ) ) {
            $rates = WC_Tax::get_base_tax_rates( $tax_class );
        } else {
            $rates = WC_Tax::get_rates( $tax_class );
        }

        if ( empty( $rates ) ) {
            return $net_price;
        }

        $taxes = WC_Tax::calc_tax( $net_price, $rates, false );
        return $net_price + array_sum( $taxes );
    }

    private static function round_price( $price, $increment = 0.5 ) {
        $increment = max( 0.01, (float) $increment );
        return round( $price / $increment ) * $increment;
    }

    public static function recalculate_recipe( $recipe_id ) {
        if ( self::RECIPE_POST_TYPE !== get_post_type( $recipe_id ) ) {
            return array();
        }

        $summary = self::calculate_recipe( $recipe_id );
        update_post_meta( $recipe_id, self::RECIPE_INGREDIENT_COST, $summary['ingredient_cost'] );
        update_post_meta( $recipe_id, self::RECIPE_LABOUR_COST, $summary['labour_cost'] );
        update_post_meta( $recipe_id, self::RECIPE_OVERHEAD_COST, $summary['overhead_cost'] );
        update_post_meta( $recipe_id, self::RECIPE_BATCH_COST, $summary['batch_cost'] );
        update_post_meta( $recipe_id, self::RECIPE_COST_PER_SERVING, $summary['cost_per_serving'] );
        update_post_meta( $recipe_id, self::RECIPE_SUGGESTED_PRICE, $summary['suggested_price'] );
        update_post_meta( $recipe_id, self::RECIPE_WARNINGS, $summary['warnings'] );
        return $summary;
    }

    private static function recalculate_all_recipes() {
        $recipe_ids = get_posts(
            array(
                'post_type'      => self::RECIPE_POST_TYPE,
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            )
        );
        foreach ( $recipe_ids as $recipe_id ) {
            self::recalculate_recipe( $recipe_id );
        }
    }

    public static function product_costing_meta_box() {
        add_meta_box(
            'persiano_hub_product_costing',
            __( 'Persiano Costing', 'persiano-hub' ),
            array( __CLASS__, 'render_product_costing_meta_box' ),
            'product',
            'side',
            'default'
        );
    }

    public static function render_product_costing_meta_box( $post ) {
        wp_nonce_field( 'persiano_hub_save_product_recipe', 'persiano_hub_product_recipe_nonce' );
        $recipe_id = absint( get_post_meta( $post->ID, self::PRODUCT_RECIPE_META, true ) );
        $recipes   = get_posts(
            array(
                'post_type'      => self::RECIPE_POST_TYPE,
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            )
        );
        ?>
        <p><label for="persiano_hub_product_recipe_id"><strong><?php esc_html_e( 'Linked recipe', 'persiano-hub' ); ?></strong></label></p>
        <select class="widefat" id="persiano_hub_product_recipe_id" name="persiano_hub_product_recipe_id">
            <option value="0"><?php esc_html_e( '— None —', 'persiano-hub' ); ?></option>
            <?php foreach ( $recipes as $recipe ) : ?>
                <option value="<?php echo esc_attr( $recipe->ID ); ?>" <?php selected( $recipe_id, $recipe->ID ); ?>><?php echo esc_html( $recipe->post_title ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php
        if ( $recipe_id ) {
            $summary = self::calculate_recipe( $recipe_id );
            echo '<div class="ph-product-costing-mini">';
            echo '<p><span>' . esc_html__( 'Cost / serving', 'persiano-hub' ) . '</span><strong>' . wp_kses_post( self::money( $summary['cost_per_serving'] ) ) . '</strong></p>';
            echo '<p><span>' . esc_html__( 'Suggested', 'persiano-hub' ) . '</span><strong>' . wp_kses_post( self::money( $summary['suggested_price'] ) ) . '</strong></p>';
            echo '<p><a href="' . esc_url( get_edit_post_link( $recipe_id ) ) . '">' . esc_html__( 'Open recipe & costing →', 'persiano-hub' ) . '</a></p>';
            echo '</div>';
        }
    }

    public static function save_product_recipe_link( $product ) {
        if ( ! isset( $_POST['persiano_hub_product_recipe_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['persiano_hub_product_recipe_nonce'] ) ), 'persiano_hub_save_product_recipe' ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $product_id    = $product->get_id();
        $old_recipe_id = absint( get_post_meta( $product_id, self::PRODUCT_RECIPE_META, true ) );
        $recipe_id     = isset( $_POST['persiano_hub_product_recipe_id'] ) ? absint( $_POST['persiano_hub_product_recipe_id'] ) : 0;

        if ( $old_recipe_id && $old_recipe_id !== $recipe_id ) {
            $linked_product = absint( get_post_meta( $old_recipe_id, self::RECIPE_PRODUCT_ID, true ) );
            if ( $linked_product === $product_id ) {
                delete_post_meta( $old_recipe_id, self::RECIPE_PRODUCT_ID );
            }
        }

        if ( $recipe_id ) {
            update_post_meta( $product_id, self::PRODUCT_RECIPE_META, $recipe_id );
            update_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, $product_id );
            self::recalculate_recipe( $recipe_id );
        } else {
            delete_post_meta( $product_id, self::PRODUCT_RECIPE_META );
        }
    }

    public static function apply_suggested_price() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to change product prices.', 'persiano-hub' ) );
        }

        $recipe_id = isset( $_GET['recipe_id'] ) ? absint( $_GET['recipe_id'] ) : 0;
        check_admin_referer( 'persiano_hub_apply_suggested_price_' . $recipe_id );

        $summary    = self::recalculate_recipe( $recipe_id );
        $product_id = absint( get_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, true ) );
        $product    = $product_id ? wc_get_product( $product_id ) : false;

        if ( $product && ! empty( $summary['suggested_price'] ) ) {
            $product->set_regular_price( wc_format_decimal( $summary['suggested_price'] ) );
            $product->set_sale_price( '' );
            $product->save();
            $message = 'price-updated';
        } else {
            $message = 'price-failed';
        }

        wp_safe_redirect(
            add_query_arg(
                'persiano_costing_notice',
                $message,
                get_edit_post_link( $recipe_id, 'url' )
            )
        );
        exit;
    }

    public static function ingredient_columns( $columns ) {
        $new = array();
        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'title' === $key ) {
                $new['persiano_purchase'] = __( 'Purchase', 'persiano-hub' );
                $new['persiano_unit_cost'] = __( 'Usable unit cost', 'persiano-hub' );
                $new['persiano_supplier'] = __( 'Supplier', 'persiano-hub' );
            }
        }
        return $new;
    }

    public static function ingredient_column_content( $column, $post_id ) {
        if ( 'persiano_purchase' === $column ) {
            echo esc_html( get_post_meta( $post_id, self::ING_PURCHASE_QTY, true ) . ' ' . get_post_meta( $post_id, self::ING_PURCHASE_UNIT, true ) );
            echo '<br><strong>' . wp_kses_post( self::money( (float) get_post_meta( $post_id, self::ING_PURCHASE_COST, true ) ) ) . '</strong>';
        } elseif ( 'persiano_unit_cost' === $column ) {
            $cost = (float) get_post_meta( $post_id, self::ING_UNIT_COST, true );
            $unit = get_post_meta( $post_id, self::ING_BASE_UNIT, true );
            echo $cost > 0 ? wp_kses_post( self::money( $cost ) ) . ' / ' . esc_html( $unit ) : '—';
        } elseif ( 'persiano_supplier' === $column ) {
            $supplier = get_post_meta( $post_id, self::ING_SUPPLIER, true );
            echo $supplier ? esc_html( $supplier ) : '—';
        }
    }

    public static function recipe_columns( $columns ) {
        $new = array();
        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'title' === $key ) {
                $new['persiano_product']   = __( 'Product', 'persiano-hub' );
                $new['persiano_cost']      = __( 'Cost / serving', 'persiano-hub' );
                $new['persiano_price']     = __( 'Current price', 'persiano-hub' );
                $new['persiano_suggested'] = __( 'Suggested', 'persiano-hub' );
                $new['persiano_margin']    = __( 'Margin', 'persiano-hub' );
            }
        }
        return $new;
    }

    public static function recipe_column_content( $column, $post_id ) {
        $summary    = self::calculate_recipe( $post_id );
        $product_id = absint( get_post_meta( $post_id, self::RECIPE_PRODUCT_ID, true ) );
        $product    = $product_id ? wc_get_product( $product_id ) : false;
        $price      = $product ? self::decimal( $product->get_price() ) : 0;
        $net_price  = $product && $price > 0 && function_exists( 'wc_get_price_excluding_tax' ) ? (float) wc_get_price_excluding_tax( $product, array( 'qty' => 1, 'price' => $price ) ) : $price;
        $margin     = $net_price > 0 ? ( ( $net_price - $summary['cost_per_serving'] ) / $net_price ) * 100 : null;

        if ( 'persiano_product' === $column ) {
            echo $product ? '<a href="' . esc_url( get_edit_post_link( $product_id ) ) . '">' . esc_html( $product->get_name() ) . '</a>' : '—';
        } elseif ( 'persiano_cost' === $column ) {
            echo wp_kses_post( self::money( $summary['cost_per_serving'] ) );
        } elseif ( 'persiano_price' === $column ) {
            echo $price > 0 ? wp_kses_post( self::money( $price ) ) : '—';
        } elseif ( 'persiano_suggested' === $column ) {
            echo wp_kses_post( self::money( $summary['suggested_price'] ) );
        } elseif ( 'persiano_margin' === $column ) {
            echo null !== $margin ? esc_html( number_format_i18n( $margin, 1 ) . '%' ) : '—';
        }
    }

    private static function legacy_pricing_detected() {
        $active = (array) get_option( 'active_plugins', array() );
        foreach ( $active as $plugin ) {
            if ( false !== strpos( $plugin, 'persiano-dish-pricing' ) ) {
                return true;
            }
        }
        return false;
    }

    public static function render_dashboard_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $ingredient_count = wp_count_posts( self::INGREDIENT_POST_TYPE );
        $recipe_count     = wp_count_posts( self::RECIPE_POST_TYPE );
        $ingredients      = isset( $ingredient_count->publish ) ? (int) $ingredient_count->publish : 0;
        $ingredients     += isset( $ingredient_count->draft ) ? (int) $ingredient_count->draft : 0;
        $recipes          = isset( $recipe_count->publish ) ? (int) $recipe_count->publish : 0;
        $recipes         += isset( $recipe_count->draft ) ? (int) $recipe_count->draft : 0;

        $recipe_ids = get_posts(
            array(
                'post_type'      => self::RECIPE_POST_TYPE,
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => 12,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                'fields'         => 'ids',
            )
        );

        $linked = 0;
        $all_recipe_ids = get_posts(
            array(
                'post_type'      => self::RECIPE_POST_TYPE,
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            )
        );
        foreach ( $all_recipe_ids as $recipe_id ) {
            if ( absint( get_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, true ) ) ) {
                $linked++;
            }
        }
        ?>
        <div class="wrap ph-costing-dashboard">
            <div class="ph-costing-hero">
                <div>
                    <span class="ph-costing-eyebrow"><?php esc_html_e( 'Persiano Hub', 'persiano-hub' ); ?></span>
                    <h1><?php esc_html_e( 'Pricing & Costing', 'persiano-hub' ); ?></h1>
                    <p><?php esc_html_e( 'Build your ingredient cost database once, then let recipes calculate real batch costs, cost per serving and suggested tax-inclusive selling prices.', 'persiano-hub' ); ?></p>
                </div>
                <div class="ph-costing-actions">
                    <a class="button button-primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::INGREDIENT_POST_TYPE ) ); ?>"><?php esc_html_e( 'Add ingredient', 'persiano-hub' ); ?></a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::RECIPE_POST_TYPE ) ); ?>"><?php esc_html_e( 'Add recipe & costing', 'persiano-hub' ); ?></a>
                </div>
            </div>

            <?php if ( self::legacy_pricing_detected() ) : ?>
                <div class="notice notice-info inline"><p><strong><?php esc_html_e( 'Existing Persiano Pricing plugin detected.', 'persiano-hub' ); ?></strong> <?php esc_html_e( 'This new recipe-costing module does not overwrite its data. A controlled import/migration can be added after we review the legacy database together.', 'persiano-hub' ); ?></p></div>
            <?php endif; ?>

            <div class="ph-costing-stats">
                <div><strong><?php echo esc_html( $ingredients ); ?></strong><span><?php esc_html_e( 'Ingredients', 'persiano-hub' ); ?></span></div>
                <div><strong><?php echo esc_html( $recipes ); ?></strong><span><?php esc_html_e( 'Recipes', 'persiano-hub' ); ?></span></div>
                <div><strong><?php echo esc_html( $linked ); ?></strong><span><?php esc_html_e( 'Linked products', 'persiano-hub' ); ?></span></div>
                <div><strong><?php echo esc_html( max( 0, $recipes - $linked ) ); ?></strong><span><?php esc_html_e( 'Need product link', 'persiano-hub' ); ?></span></div>
            </div>

            <section class="ph-costing-panel">
                <div class="ph-costing-heading-row"><div><h2><?php esc_html_e( 'Recent recipe costing', 'persiano-hub' ); ?></h2><p><?php esc_html_e( 'Prices shown are the current WooCommerce customer-facing prices.', 'persiano-hub' ); ?></p></div><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . self::RECIPE_POST_TYPE ) ); ?>"><?php esc_html_e( 'View all recipes →', 'persiano-hub' ); ?></a></div>
                <?php if ( $recipe_ids ) : ?>
                    <div class="ph-costing-table-wrap"><table class="widefat striped ph-costing-table"><thead><tr><th><?php esc_html_e( 'Recipe', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Product', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Cost / serving', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Current price', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Suggested', 'persiano-hub' ); ?></th><th><?php esc_html_e( 'Margin', 'persiano-hub' ); ?></th></tr></thead><tbody>
                    <?php foreach ( $recipe_ids as $recipe_id ) :
                        $summary = self::calculate_recipe( $recipe_id );
                        $product_id = absint( get_post_meta( $recipe_id, self::RECIPE_PRODUCT_ID, true ) );
                        $product = $product_id ? wc_get_product( $product_id ) : false;
                        $price = $product ? self::decimal( $product->get_price() ) : 0;
                        $net_price = $product && $price > 0 && function_exists( 'wc_get_price_excluding_tax' ) ? (float) wc_get_price_excluding_tax( $product, array( 'qty' => 1, 'price' => $price ) ) : $price;
                        $margin = $net_price > 0 ? ( ( $net_price - $summary['cost_per_serving'] ) / $net_price ) * 100 : null;
                        ?>
                        <tr><td><a href="<?php echo esc_url( get_edit_post_link( $recipe_id ) ); ?>"><strong><?php echo esc_html( get_the_title( $recipe_id ) ); ?></strong></a></td><td><?php echo $product ? esc_html( $product->get_name() ) : '—'; ?></td><td><?php echo wp_kses_post( self::money( $summary['cost_per_serving'] ) ); ?></td><td><?php echo $price > 0 ? wp_kses_post( self::money( $price ) ) : '—'; ?></td><td><strong><?php echo wp_kses_post( self::money( $summary['suggested_price'] ) ); ?></strong></td><td><?php echo null !== $margin ? esc_html( number_format_i18n( $margin, 1 ) . '%' ) : '—'; ?></td></tr>
                    <?php endforeach; ?>
                    </tbody></table></div>
                <?php else : ?>
                    <div class="ph-costing-empty"><p><?php esc_html_e( 'No recipe costing records yet. Start by adding your ingredients, then build your first recipe.', 'persiano-hub' ); ?></p></div>
                <?php endif; ?>
            </section>

            <section class="ph-costing-panel ph-costing-panel--workflow">
                <h2><?php esc_html_e( 'How the system fits together', 'persiano-hub' ); ?></h2>
                <div class="ph-costing-flow"><span><?php esc_html_e( 'Ingredient purchase cost', 'persiano-hub' ); ?></span><b>→</b><span><?php esc_html_e( 'Recipe quantities', 'persiano-hub' ); ?></span><b>→</b><span><?php esc_html_e( 'Batch & serving cost', 'persiano-hub' ); ?></span><b>→</b><span><?php esc_html_e( 'Suggested displayed price', 'persiano-hub' ); ?></span><b>→</b><span><?php esc_html_e( 'WooCommerce product', 'persiano-hub' ); ?></span></div>
            </section>
        </div>
        <?php
    }

    public static function admin_assets( $hook ) {
        $screen = get_current_screen();
        if ( ! $screen ) {
            return;
        }

        $is_costing = in_array( $screen->post_type, array( self::INGREDIENT_POST_TYPE, self::RECIPE_POST_TYPE, 'product' ), true ) || self::MENU_SLUG === $screen->id || false !== strpos( $screen->id, self::MENU_SLUG );
        if ( ! $is_costing ) {
            return;
        }

        wp_enqueue_script( 'jquery' );
        $currency_symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';

        $js = <<<'JS'
(function($){
    'use strict';

    var unitMultipliers = {g:1,kg:1000,oz:28.349523125,lb:453.59237,ml:1,l:1000,tsp:5,tbsp:15,cup:250,each:1};
    var unitFamilies = {g:'mass',kg:'mass',oz:'mass',lb:'mass',ml:'volume',l:'volume',tsp:'volume',tbsp:'volume',cup:'volume',each:'count'};
    var baseUnits = {mass:'g',volume:'ml',count:'each'};
    var currency = window.PersianoCostingCurrency || '$';

    function money(value){
        value = Number(value || 0);
        return currency + value.toFixed(2);
    }

    function recalcIngredient(){
        var qty = parseFloat($('#persiano_ing_purchase_qty').val()) || 0;
        var unit = $('#persiano_ing_purchase_unit').val();
        var cost = parseFloat($('#persiano_ing_purchase_cost').val()) || 0;
        var waste = parseFloat($('#persiano_ing_waste_pct').val()) || 0;
        var family = unitFamilies[unit] || '';
        var base = baseUnits[family] || '';
        var usable = qty * (unitMultipliers[unit] || 0) * (1 - Math.min(99,Math.max(0,waste))/100);
        var unitCost = usable > 0 ? cost / usable : 0;
        $('#ph-live-unit-cost').text(unitCost > 0 ? money(unitCost) + ' / ' + base : '—');
        if(unitCost > 0 && (base === 'g' || base === 'ml')){
            $('#ph-live-equivalent').text(money(unitCost * 1000) + (base === 'g' ? ' / kg' : ' / L'));
        } else {
            $('#ph-live-equivalent').text('—');
        }
    }

    function rowCost($row){
        var $option = $row.find('.ph-recipe-ingredient option:selected');
        var unitCost = parseFloat($option.data('unit-cost')) || 0;
        var baseUnit = String($option.data('base-unit') || '');
        var qty = parseFloat($row.find('.ph-recipe-qty').val()) || 0;
        var unit = $row.find('.ph-recipe-unit').val();
        var family = unitFamilies[unit] || '';
        var expectedBase = baseUnits[family] || '';
        if(!unitCost || !qty || !baseUnit || expectedBase !== baseUnit){
            $row.find('.ph-recipe-line-cost').text('—');
            return 0;
        }
        var cost = qty * (unitMultipliers[unit] || 0) * unitCost;
        $row.find('.ph-recipe-line-cost').text(money(cost));
        return cost;
    }

    function recalcRecipe(){
        if(!$('#ph-recipe-items').length){ return; }
        var ingredients = 0;
        $('#ph-recipe-items .ph-recipe-row:not(.ph-recipe-row--header)').each(function(){ ingredients += rowCost($(this)); });
        var packaging = parseFloat($('#persiano_recipe_packaging_cost').val()) || 0;
        var labourMinutes = parseFloat($('#persiano_recipe_labour_minutes').val()) || 0;
        var labourRate = parseFloat($('#persiano_recipe_labour_rate').val()) || 0;
        var other = parseFloat($('#persiano_recipe_other_cost').val()) || 0;
        var overheadPct = parseFloat($('#persiano_recipe_overhead_pct').val()) || 0;
        var targetPct = parseFloat($('#persiano_recipe_target_food_cost_pct').val()) || 35;
        var yieldQty = parseFloat($('#persiano_recipe_yield_qty').val()) || 1;
        var labour = (labourMinutes / 60) * labourRate;
        var base = ingredients + packaging + labour + other;
        var batch = base + (base * overheadPct / 100);
        var perServing = batch / Math.max(0.0001,yieldQty);
        var taxFactor = parseFloat($('#ph-recipe-summary').data('tax-factor')) || 1;
        var suggested = (perServing / (Math.max(1,targetPct)/100)) * taxFactor;
        suggested = Math.round(suggested / 0.5) * 0.5;
        $('[data-summary="ingredients"]').text(money(ingredients));
        $('[data-summary="labour"]').text(money(labour));
        $('[data-summary="batch"]').text(money(batch));
        $('[data-summary="per-serving"]').text(money(perServing));
        $('[data-summary="suggested"]').text(money(suggested));
    }

    function reindexRows(){
        $('#ph-recipe-items .ph-recipe-row:not(.ph-recipe-row--header)').each(function(index){
            $(this).attr('data-index',index);
            $(this).find('[name]').each(function(){
                this.name = this.name.replace(/persiano_recipe_items\[[^\]]+\]/,'persiano_recipe_items['+index+']');
            });
        });
    }

    $(document).on('input change','.ph-ing-live',recalcIngredient);
    $(document).on('input change','.ph-recipe-ingredient,.ph-recipe-qty,.ph-recipe-unit,.ph-recipe-live',recalcRecipe);

    $(document).on('click','#ph-add-recipe-ingredient',function(){
        var template = $('#ph-recipe-row-template').html() || '';
        var index = $('#ph-recipe-items .ph-recipe-row:not(.ph-recipe-row--header)').length;
        template = template.replace(/__INDEX__/g,index);
        $('#ph-recipe-items').append(template);
        recalcRecipe();
    });

    $(document).on('click','.ph-remove-recipe-row',function(){
        $(this).closest('.ph-recipe-row').remove();
        reindexRows();
        recalcRecipe();
    });

    $(function(){ recalcIngredient(); recalcRecipe(); });
})(jQuery);
JS;
        wp_add_inline_script( 'jquery', 'window.PersianoCostingCurrency=' . wp_json_encode( $currency_symbol ) . ';' . $js );

        $css = <<<'CSS'
.ph-costing-grid{display:grid;gap:18px;margin:12px 0 4px}.ph-costing-grid--2{grid-template-columns:repeat(2,minmax(0,1fr))}.ph-costing-grid--3{grid-template-columns:repeat(3,minmax(0,1fr))}.ph-costing-field label{display:block;font-weight:600;margin-bottom:7px}.ph-costing-field--wide{grid-column:span 2}.ph-costing-field--full{margin-top:18px}.ph-input-suffix{display:flex;align-items:center;max-width:100%}.ph-input-suffix input{border-radius:4px 0 0 4px!important}.ph-input-suffix span{padding:5px 10px;border:1px solid #8c8f94;border-left:0;background:#f6f7f7;border-radius:0 4px 4px 0;min-height:30px;box-sizing:border-box}.ph-cost-summary{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1px;background:#ddd;border:1px solid #ddd;border-radius:10px;overflow:hidden;margin:22px 0}.ph-cost-summary>div{display:flex;justify-content:space-between;gap:20px;padding:15px 17px;background:#fff}.ph-cost-summary span{color:#646970}.ph-cost-summary strong{font-size:15px}.ph-cost-summary--recipe{grid-template-columns:repeat(3,minmax(0,1fr))}.ph-cost-summary__highlight{background:#fff8e5!important}.ph-costing-section{padding:18px 0;border-bottom:1px solid #e2e4e7}.ph-costing-section:last-of-type{border-bottom:0}.ph-costing-section h3{margin:0 0 12px;font-size:17px}.ph-costing-heading-row{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:14px}.ph-costing-heading-row h2,.ph-costing-heading-row h3,.ph-costing-heading-row p{margin-top:0}.ph-recipe-items{border:1px solid #dcdcde;border-radius:10px;overflow:hidden}.ph-recipe-row{display:grid;grid-template-columns:minmax(220px,2fr) 110px 100px 110px 34px;gap:10px;align-items:center;padding:10px 12px;border-top:1px solid #f0f0f1;background:#fff}.ph-recipe-row:first-child{border-top:0}.ph-recipe-row--header{font-weight:600;background:#f6f7f7;color:#50575e}.ph-remove-recipe-row{font-size:24px;text-decoration:none;text-align:center}.ph-recipe-line-cost{text-align:right}.ph-costing-warning ul{list-style:disc;padding-left:24px}.ph-apply-price-row{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.ph-apply-price-row span{color:#646970}.ph-history-list{display:grid;gap:10px}.ph-history-entry{border-bottom:1px solid #eee;padding-bottom:10px;display:grid;gap:2px}.ph-history-entry:last-child{border-bottom:0}.ph-history-entry span,.ph-history-entry small{color:#646970}.ph-product-costing-mini{margin-top:14px;padding-top:10px;border-top:1px solid #ddd}.ph-product-costing-mini p{display:flex;justify-content:space-between;gap:10px}.ph-product-costing-mini p:last-child{display:block}.ph-costing-dashboard{max-width:1180px}.ph-costing-hero{display:flex;justify-content:space-between;gap:30px;align-items:flex-end;padding:30px 0 22px}.ph-costing-hero h1{font-size:34px;margin:4px 0 8px}.ph-costing-hero p{font-size:16px;color:#646970;max-width:760px}.ph-costing-eyebrow{text-transform:uppercase;letter-spacing:.15em;font-weight:700;color:#9a263a;font-size:12px}.ph-costing-actions{display:flex;gap:10px;flex-wrap:wrap}.ph-costing-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px;margin:22px 0}.ph-costing-stats>div{padding:20px;border:1px solid #ddd;border-radius:12px;background:#fff}.ph-costing-stats strong{display:block;font-size:30px;color:#9a263a}.ph-costing-stats span{color:#646970}.ph-costing-panel{margin:20px 0;padding:22px 24px;background:#fff;border:1px solid #ddd;border-radius:14px}.ph-costing-table-wrap{overflow:auto}.ph-costing-table th,.ph-costing-table td{padding:12px}.ph-costing-empty{padding:24px;text-align:center;background:#f6f7f7;border-radius:10px}.ph-costing-flow{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.ph-costing-flow span{padding:10px 13px;border-radius:999px;background:#f6f0e7}.ph-costing-flow b{color:#9a263a}.column-persiano_purchase,.column-persiano_unit_cost,.column-persiano_cost,.column-persiano_price,.column-persiano_suggested,.column-persiano_margin{width:120px}.column-persiano_supplier,.column-persiano_product{width:150px}@media(max-width:900px){.ph-costing-grid--2,.ph-costing-grid--3,.ph-cost-summary--recipe,.ph-costing-stats{grid-template-columns:1fr 1fr}.ph-costing-field--wide{grid-column:span 2}.ph-recipe-row{grid-template-columns:1fr 90px 90px 90px 30px}.ph-costing-hero{display:block}.ph-costing-actions{margin-top:16px}}@media(max-width:620px){.ph-costing-grid--2,.ph-costing-grid--3,.ph-cost-summary,.ph-cost-summary--recipe,.ph-costing-stats{grid-template-columns:1fr}.ph-costing-field--wide{grid-column:auto}.ph-recipe-row--header{display:none}.ph-recipe-row{grid-template-columns:1fr 1fr;gap:8px}.ph-recipe-line-cost{text-align:left}.ph-remove-recipe-row{position:absolute;right:20px}.ph-recipe-row{position:relative;padding-right:46px}}
CSS;
        wp_register_style( 'persiano-hub-costing-admin', false, array(), PERSIANO_HUB_VERSION );
        wp_enqueue_style( 'persiano-hub-costing-admin' );
        wp_add_inline_style( 'persiano-hub-costing-admin', $css );

        if ( isset( $_GET['persiano_costing_notice'] ) && 'price-updated' === sanitize_key( wp_unslash( $_GET['persiano_costing_notice'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            add_action( 'admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'WooCommerce product price updated from the recipe suggestion.', 'persiano-hub' ) . '</p></div>';
            } );
        }
    }
}
