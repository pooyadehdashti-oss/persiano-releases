<?php
/**
 * Plugin Name: Persiano Hub
 * Plugin URI: https://persianodish.com/
 * Description: Persiano Dish business tools for products, ordering, fulfilment, mailing-list subscriptions and multi-channel publishing.
 * Version: 0.12.0
 * Author: Persiano Dish
 * Text Domain: persiano-hub
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PERSIANO_HUB_VERSION', '0.12.0' );
define( 'PERSIANO_HUB_FILE', __FILE__ );
define( 'PERSIANO_HUB_PATH', plugin_dir_path( __FILE__ ) );
define( 'PERSIANO_HUB_URL', plugin_dir_url( __FILE__ ) );

require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-product-fields.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-tax.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-commerce.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-fulfilment.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-newsletter.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-advance-orders.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-email-branding.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-publishing.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-google-reviews.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-costing.php';
require_once PERSIANO_HUB_PATH . 'includes/class-persiano-hub-updater.php';

function persiano_hub_boot() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'persiano_hub_missing_woocommerce_notice' );
        return;
    }

    Persiano_Hub_Product_Fields::init();
    Persiano_Hub_Tax::init();
    Persiano_Hub_Commerce::init();
    Persiano_Hub_Fulfilment::init();
    Persiano_Hub_Newsletter::init();
    Persiano_Hub_Advance_Orders::init();
    Persiano_Hub_Email_Branding::init();
    Persiano_Hub_Publishing::init();
    Persiano_Hub_Google_Reviews::init();
    Persiano_Hub_Costing::init();
    Persiano_Hub_Updater::init();
}
add_action( 'plugins_loaded', 'persiano_hub_boot' );

function persiano_hub_missing_woocommerce_notice() {
    if ( ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>Persiano Hub</strong> requires WooCommerce.</p></div>';
}

function persiano_hub_ensure_categories() {
    if ( ! taxonomy_exists( 'product_cat' ) ) {
        return;
    }

    $categories = array(
        'this-week' => 'This Week',
        'pantry'    => 'Pantry',
    );

    foreach ( $categories as $slug => $name ) {
        if ( ! term_exists( $slug, 'product_cat' ) ) {
            wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
        }
    }
}
add_action( 'init', 'persiano_hub_ensure_categories', 30 );

function persiano_hub_activate() {
    Persiano_Hub_Newsletter::install();
    update_option( 'persiano_hub_db_version', PERSIANO_HUB_VERSION );
}
register_activation_hook( __FILE__, 'persiano_hub_activate' );

function persiano_hub_maybe_upgrade() {
    $version = get_option( 'persiano_hub_db_version', '0' );
    if ( version_compare( $version, PERSIANO_HUB_VERSION, '<' ) ) {
        Persiano_Hub_Newsletter::install();

        /*
         * Do not create the advance-order placeholder during plugins_loaded.
         * WooCommerce's product data store can still be in an early bootstrap
         * state here, and duplicate-SKU validation can turn an upgrade into a
         * site-wide fatal error. The placeholder is created safely/lazily on
         * init and again when an advance order is actually added to the cart.
         */
        update_option( 'persiano_hub_db_version', PERSIANO_HUB_VERSION );
    }
}
add_action( 'plugins_loaded', 'persiano_hub_maybe_upgrade', 20 );


/**
 * Ensure WooCommerce has real Cart and Checkout pages assigned.
 *
 * Some older stores or partially configured installs have page IDs set to 0,
 * which makes wc_get_cart_url() / wc_get_checkout_url() fall back to home.
 * Existing non-empty pages are preserved; missing pages are created with the
 * standard WooCommerce shortcodes so both classic checkout and the custom
 * Persiano theme templates work immediately.
 */
function persiano_hub_ensure_woocommerce_pages() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }

    $setup_version = get_option( 'persiano_hub_commerce_setup_version', '0' );
    if ( version_compare( $setup_version, PERSIANO_HUB_VERSION, '>=' ) ) {
        return;
    }

    $pages = array(
        'cart' => array(
            'option'  => 'woocommerce_cart_page_id',
            'title'   => __( 'Cart', 'persiano-hub' ),
            'content' => '[woocommerce_cart]',
        ),
        'checkout' => array(
            'option'  => 'woocommerce_checkout_page_id',
            'title'   => __( 'Checkout', 'persiano-hub' ),
            'content' => '[woocommerce_checkout]',
        ),
    );

    foreach ( $pages as $slug => $config ) {
        $page_id = absint( get_option( $config['option'], 0 ) );
        $page    = $page_id ? get_post( $page_id ) : null;

        if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status ) {
            $existing = get_page_by_path( $slug );

            if ( $existing && 'trash' !== $existing->post_status ) {
                $page_id = (int) $existing->ID;
                $page    = $existing;
            } else {
                $page_id = wp_insert_post(
                    array(
                        'post_title'   => $config['title'],
                        'post_name'    => $slug,
                        'post_status'  => 'publish',
                        'post_type'    => 'page',
                        'post_content' => $config['content'],
                    )
                );
                $page = $page_id && ! is_wp_error( $page_id ) ? get_post( $page_id ) : null;
            }
        }

        if ( $page && $page_id && ! is_wp_error( $page_id ) ) {
            if ( 'publish' !== $page->post_status ) {
                wp_update_post(
                    array(
                        'ID'          => $page_id,
                        'post_status' => 'publish',
                    )
                );
            }

            if ( '' === trim( (string) $page->post_content ) ) {
                wp_update_post(
                    array(
                        'ID'           => $page_id,
                        'post_content' => $config['content'],
                    )
                );
            }

            update_option( $config['option'], $page_id );
        }
    }

    update_option( 'persiano_hub_commerce_setup_version', PERSIANO_HUB_VERSION );
    flush_rewrite_rules( false );
}
add_action( 'admin_init', 'persiano_hub_ensure_woocommerce_pages', 25 );

/**
 * Public helper for themes and future Persiano Hub modules.
 *
 * @param int $product_id Product ID.
 * @return array<string,mixed>
 */
function persiano_hub_get_product_details( $product_id ) {
    return Persiano_Hub_Product_Fields::get_product_details( $product_id );
}

/** Return Persiano course labels for theme filters. */
function persiano_hub_get_course_options() {
    return Persiano_Hub_Product_Fields::get_course_options();
}

/** Return Persiano dietary labels. */
function persiano_hub_get_dietary_options() {
    return Persiano_Hub_Product_Fields::get_dietary_options();
}

/** Return Persiano available-alteration labels. */
function persiano_hub_get_alteration_options() {
    return Persiano_Hub_Product_Fields::get_alteration_options();
}

/**
 * Render the Persiano mailing-list form from the theme.
 *
 * @param array<string,mixed> $args Form options.
 */
function persiano_hub_render_newsletter_form( $args = array() ) {
    Persiano_Hub_Newsletter::render_form( $args );
}
